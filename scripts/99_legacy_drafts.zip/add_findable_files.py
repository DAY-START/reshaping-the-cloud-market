# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

import os ,shutil ,csv 

BASE =r"D:\study\date\news\111zuixin"
MANIFEST =os .path .join (BASE ,"归集清单.csv")

# (source path, target subfolder) - only "found" (existing on disk)
TO_ADD =[
(r"D:\study\date\ai_computing_news\ai_computing_web_collector\web_ai_news_output\AI_Computing_Web_News_20210701_20260630.jsonl",
"web_collector"),
(r"D:\study\test2\ai_computing_news_202107_202607.jsonl",
"test2"),
(r"D:\ai_compute_zh_collector\verified_seed_zh.jsonl",
"external_verified_seed"),
]

def human_readable (n ):
    s =float (n )
    for u in ["B","KB","MB","GB"]:
        if s <1024 :
            return f"{s :.2f} {u }"
        s /=1024 
    return f"{s :.2f} TB"

added_rows =[]
for src ,sub in TO_ADD :
    fname =os .path .basename (src )
    if not os .path .isfile (src ):
        print (f"[Skip] Does not exist: {src }")
        continue 
    dest_dir =os .path .join (BASE ,sub )
    os .makedirs (dest_dir ,exist_ok =True )
    dest =os .path .join (dest_dir ,fname )
    size =os .path .getsize (src )
    if size ==0 :
        print (f"[Copy] {sub }/{fname } (empty file 0 bytes)")
    else :
        print (f"[Copy] {sub }/ {fname } ({human_readable (size )})")
    shutil .copy2 (src ,dest )
    added_rows .append ([sub ,fname ,src ,dest ,human_readable (size ),
    "Supplementary copy"if size >0 else "Supplementary copy (empty file 0 bytes)"])

    # Updated list: Removed rows that originally listed them as "skipped" and added new supplemental copy rows
rows =[]
try :
    with open (MANIFEST ,encoding ="utf-8-sig",newline ="")as f :
        reader =list (csv .reader (f ))
    header =reader [0 ]
    body =reader [1 :]
    added_basenames ={r [1 ]for r in added_rows }
    # Filter out files that have been added in skips/errors
    body =[r for r in body if not (len (r )>1 and r [1 ]in added_basenames and r [0 ].startswith ("("))]
    rows =[header ]+body +added_rows 
except Exception as e :
    print (f"[Warning] Failed to read the original list, will create a new one: {e }")
    rows =[["目标子文件夹","文件名","原路径","新路径","大小","状态"]]+added_rows 

with open (MANIFEST ,"w",encoding ="utf-8-sig",newline ="")as f :
    csv .writer (f ).writerows (rows )

print (f"\nAdded {len (added_rows )} files to {BASE }")
print (f"The list has been updated: {MANIFEST }")
