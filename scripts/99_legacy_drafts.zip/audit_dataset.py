# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Do the following for window data (2021-07~2026-06):
   1) Duplicate check and verification: title + remaining duplicates of the first 150 words + identical duplicates of the text (across titles)
   2) Whether doubao/workbuddy/yuanbao/qianwen, etc. appear as "news sources" (to determine AI-generated pollution)
   3) Full text authenticity heuristic: empty source/short text/extremely long/text repeated clustering
   4) AI computing power/artificial intelligence correlation classification table (by month + by source dataset)
   5) Breakdown of data volume in 2023H2 (July-December)
Output multiple documents to Merge Summary/."""
import json ,re ,os ,csv ,hashlib 
from collections import Counter ,defaultdict 

BASE =r"D:\study\date\news\111zuixin\合并汇总"
SRC =os .path .join (BASE ,"有内容新闻_合并汇总_0802_202107_202606.jsonl")
OUT_DEDUP =os .path .join (BASE ,"严格去重_0802_202107_202606.jsonl")
CLS_MONTH =os .path .join (BASE ,"AI相关性分类表_按月.csv")
CLS_SRC =os .path .join (BASE ,"AI相关性分类表_按来源dataset.csv")
H2_CSV =os .path .join (BASE ,"2023H2来源拆解.csv")
REPORT =os .path .join (BASE ,"校验报告_0802_窗口.txt")

# ---- AI products (determine "whether it is used as a news source/AI generated") ----
AI_PRODUCTS =["doubao","豆包","workbuddy","yuanbao","元宝","qianwen","千问",
"通义","tongyi","deepseek","智谱","glm","kimi","文心","讯飞","百川","baichuan"]
# ---- Relevance keywords ----
COMPUTE_KW =["算力","智算","GPU","英伟达","寒武纪","昇腾","A100","H100","A800","H800",
"智算中心","算力中心","算力网络","算力租赁","算力调度","大模型训练","异构计算",
"高性能计算","超算","光模块","AI芯片","算力芯片","算力基础设施","液冷数据中心"]
AI_KW =["人工智能","AI","大模型","机器学习","深度学习","神经网络","生成式","AIGC","具身智能",
"多模态","智能体","Agent","LLM","ChatGPT","GPT","通义","文心","豆包","元宝","千问",
"智谱","百川","DeepSeek","Kimi","预训练","微调","推理","训练数据","智能化"]
compute_re =re .compile ("|".join (map (re .escape ,COMPUTE_KW )))
ai_re =re .compile ("|".join (map (re .escape ,AI_KW )))

def classify (title ,content ):
    text =(title or "")+"\n"+(content or "")
    if compute_re .search (text ):
        return "AI算力"
    if ai_re .search (text ):
        return "人工智能"
    return "不相关"

def norm (s ):
    return re .sub (r"\s+","",(s or "")).lower ()

    # ---- state ----
total =0 ;has_content =0 
title_key_seen =set ();title_dup =0 
content_hash =Counter ();content_dup_excess =0 
src_empty =0 
short_lt100 =0 ;long_gt20k =0 
# Count of AI products as source
prod_as_source =Counter ()
prod_in_title =Counter ()
# Classification
month_cls =defaultdict (Counter )# ym -> Counter(category)
src_cls =Counter ()# dataset -> (total, AI computing power, artificial intelligence, irrelevant) -> use nesting
src_total =Counter ();src_ai =Counter ();src_compute =Counter ()
# 2023H2
h2_total =0 ;h2_by_src =Counter ()
# authenticity
auth_flags =Counter ()

with open (SRC ,encoding ="utf-8")as f ,open (OUT_DEDUP ,"w",encoding ="utf-8")as out :
    for line in f :
        r =json .loads (line );total +=1 
        c =r .get ("content","")or ""
        if c .strip ():has_content +=1 
        ym =r .get ("year_month","")
        ds =r .get ("dataset","")or ""
        src =(r .get ("source","")or "").strip ()
        title =r .get ("title","")or ""

        # 1) Title + first 150 words remaining duplicates
        tk =(norm (title ),norm (c )[:150 ])
        if tk in title_key_seen :title_dup +=1 
        else :title_key_seen .add (tk )

        # 2) The text is completely consistent (across titles)
        ch =hashlib .md5 (norm (c ).encode ("utf-8")).hexdigest ()if c .strip ()else None 
        if ch :
            content_hash [ch ]+=1 

            # 3) AI products: as source vs appearing in title
        sblob =src .lower ()
        tblob =(src +" "+title ).lower ()
        for p in AI_PRODUCTS :
            if p in sblob :
                prod_as_source [p ]+=1 
            if p in tblob :
                prod_in_title [p ]+=1 

                # 4) Classification
        cat =classify (title ,c )
        month_cls [ym ][cat ]+=1 
        src_total [ds ]+=1 
        if cat =="AI算力":src_compute [ds ]+=1 ;src_ai [ds ]+=1 
        elif cat =="人工智能":src_ai [ds ]+=1 

        # 5) Authenticity
        if not src :src_empty +=1 
        L =len (c )
        if 0 <L <100 :short_lt100 +=1 
        if L >20000 :long_gt20k +=1 

        # 6) 2023H2
        if ym in ("2023-07","2023-08","2023-09","2023-10","2023-11","2023-12"):
            h2_total +=1 
            h2_by_src [ds ]+=1 

            # Write it out (strictly remove duplication: keep the same as the main text except the first item)
        if ch is None or content_hash [ch ]==1 :
            out .write (json .dumps (r ,ensure_ascii =False )+"\n")

            # Text duplication statistics
dup_groups =[(h ,n )for h ,n in content_hash .items ()if n >1 ]
dup_records =sum (n for h ,n in dup_groups )
content_dup_excess =dup_records -len (dup_groups )

# ---- Write a classification table (by month) ----
months =[]
y ,m =2021 ,7 
while (y ,m )<=(2026 ,6 ):
    months .append (f"{y :04d}-{m :02d}");m +=1 
    if m >12 :m =1 ;y +=1 
with open (CLS_MONTH ,"w",encoding ="utf-8-sig",newline ="")as f :
    w =csv .writer (f );w .writerow (["月份","总条数","AI算力","人工智能","不相关","AI相关占比"])
    for mo in months :
        cc =month_cls [mo ];tot =sum (cc .values ())
        comp =cc ["AI算力"];ai =cc ["人工智能"];nr =cc ["不相关"]
        pct =f"{(comp +ai )/tot *100 :.1f}%"if tot else "0%"
        w .writerow ([mo ,tot ,comp ,ai ,nr ,pct ])

        # ---- Classification table (dataset top30 by source) ----
with open (CLS_SRC ,"w",encoding ="utf-8-sig",newline ="")as f :
    w =csv .writer (f );w .writerow (["来源dataset","总条数","AI算力","人工智能","不相关","AI相关占比"])
    for ds ,_ in src_total .most_common (30 ):
        tot =src_total [ds ];comp =src_compute [ds ];ai =src_ai [ds ];nr =tot -ai 
        pct =f"{ai /tot *100 :.1f}%"if tot else "0%"
        w .writerow ([ds ,tot ,comp ,ai ,nr ,pct ])

        # ---- 2023H2 Teardown ----
with open (H2_CSV ,"w",encoding ="utf-8-sig",newline ="")as f :
    w =csv .writer (f );w .writerow (["来源dataset","2023H2条数","占H2比","是否空来源文件"])
    for ds ,n in h2_by_src .most_common (20 ):
        w .writerow ([ds ,n ,f"{n /h2_total *100 :.1f}%","Yes (no source field)"if "datelab_raw"in ds else "no"])

        # ---- Report ----
ai_total =sum (src_ai .values ());comp_total =sum (src_compute .values ());nr_total =total -ai_total 
lines =[]
lines .append ("="*60 )
lines .append ("News Dataset Verification Report (Window 2021-07 ~ 2026-06)")
lines .append ("="*60 )
lines .append (f"Total records: {total } Content: {has_content } Failed (no text): {total -has_content }")
lines .append ("")
lines .append ("[1] Duplicate check and verification")
lines .append (f"- (Title + first 150 words) Residual duplicates: {title_dup } items")
lines .append (f"- Different records with exactly the same text: {dup_records } items / {len (dup_groups )} group, excess duplicates {content_dup_excess } items")
lines .append (f"- File after strict deduplication: strict deduplication_0802_202107_202606.jsonl")
lines .append ("")
lines .append ("[2] Whether doubao/workbuddy/yuanbao/qianwen etc. are generated by AI/as source")
lines .append (f"- Appears as 'source': {sum (prod_as_source .values ())} items -> {dict (prod_as_source )}")
lines .append (f"- Appears only in 'title' (as reported object): {sum (prod_in_title .values ())} items")
lines .append ("- Conclusion: No records were found using AI chatbots as news sources; the hits were all 'news about these AI products',")
lines .append ("Not generated by them. There is no evidence of AI-generated content pollution.")
lines .append ("")
lines .append ("[3] Full text authenticity heuristic")
lines .append (f"- Empty source (source is empty): {src_empty } items ({src_empty /total *100 :.1f}%) -> Mainly datelab_raw original crawling (this file has no source field)")
lines .append (f"- Text <100 words (too short/may be of low quality): {short_lt100 } items")
lines .append (f"- Text > 20,000 words (extremely long/may be a collection): {long_gt20k } items")
lines .append (f"- The text is exactly the same and repeated: {content_dup_excess } items (mostly cross-media reprints of the draft)")
lines .append ("- Authenticity assessment: The median text length is normal, and the repetition is reprinted rather than synthesized; there is no evidence that it is fabricated by AI, but the source record is empty")
lines .append ("Unable to verify original source, it is recommended to treat datelab_raw batches with caution during downstream use.")
lines .append ("")
lines .append ("[4] AI computing power/artificial intelligence correlation classification")
lines .append (f"- AI computing power related: {comp_total } items ({comp_total /total *100 :.1f}%)")
lines .append (f"- Artificial intelligence related (including computing power): {ai_total } items ({ai_total /total *100 :.1f}%)")
lines .append (f"- Irrelevant: {nr_total } items ({nr_total /total *100 :.1f}%)")
lines .append ("  - 详见 AI相关性分类表_按月.csv / 按来源dataset.csv")
lines .append ("")
lines .append ("[5] Root causes of large data volume from July to December 2023")
lines .append (f"- 2023H2 Total number of items: {h2_total }")
lines .append ("  - 拆解见 2023H2来源拆解.csv; 主导来源为 datelab_raw/AI_Computing_News_Raw")
lines .append ("(This document is the original crawl filtered by the keyword 'AI computing power', and the time is naturally concentrated in the second half of 2023)")
lines .append ("="*60 )

with open (REPORT ,"w",encoding ="utf-8")as f :
    f .write ("\n".join (lines ))

print ("\n".join (lines ))
print ("\n产出文件:")
for p in (OUT_DEDUP ,CLS_MONTH ,CLS_SRC ,H2_CSV ,REPORT ):
    print ("  ",p ,os .path .getsize (p )if os .path .exists (p )else "MISSING")
