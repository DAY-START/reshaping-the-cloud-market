# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Add dates for undated records in the Include Failure summary (Level 3 cover):
   1) Extract the date from the regular text 2) Extract the date from the url path 3) Re-catch the url and use metadata to extract the date
   Rewrite consolidated files after backfilling + Regenerate monthly sheets + Backfill reports."""
import json ,re ,os ,csv ,threading 
from collections import Counter 
from concurrent .futures import ThreadPoolExecutor 

BASE =r"D:\study\date\news\111zuixin\合并汇总"
SRC =os .path .join (BASE ,"有内容新闻_合并汇总_0802_含失败.jsonl")
OUT =os .path .join (BASE ,"有内容新闻_合并汇总_0802_含失败_补日期.jsonl")
MONTH_CSV =os .path .join (BASE ,"月度统计表_合并汇总_0802_含失败_补日期.csv")
REPORT =os .path .join (BASE ,"无日期回填报告.csv")

# ----------------Date Extraction----------------
DATE_BODY =[
re .compile (r"(\d{4})[年\-/.](\d{1,2})[月\-/.](\d{1,2})"),
re .compile (r"(\d{4})年(\d{1,2})月"),
re .compile (r"(\d{4})-(\d{2})"),
]
def extract_date_text (text ):
    if not text :return None 
    for i ,rx in enumerate (DATE_BODY ):
        m =rx .search (text )
        if not m :continue 
        y =int (m .group (1 ))
        if not (1990 <=y <=2026 ):continue 
        if i ==0 :
            mo ,d =int (m .group (2 )),int (m .group (3 ))
            if 1 <=mo <=12 and 1 <=d <=31 :
                return f"{y :04d}-{mo :02d}-{d :02d}"
        else :
            mo =int (m .group (2 ))
            if 1 <=mo <=12 :
                return f"{y :04d}-{mo :02d}-01"
    return None 

DATE_URL =[
re .compile (r"(\d{4})[/-](\d{1,2})[/-](\d{1,2})"),# 2023/04/21  2023-04-21
re .compile (r"(\d{4})/(\d{2})(\d{2})"),# 2023/0421
re .compile (r"[/-](\d{4})(\d{2})(\d{2})[/.]"),# 20230421 as segment
]
def extract_date_from_url (url ):
    if not url :return None 
    for i ,rx in enumerate (DATE_URL ):
        m =rx .search (url )
        if not m :continue 
        if i ==0 :
            y ,mo ,d =int (m .group (1 )),int (m .group (2 )),int (m .group (3 ))
        else :
            y ,mo ,d =int (m .group (1 )),int (m .group (2 )),int (m .group (3 ))
        if 1990 <=y <=2026 and 1 <=mo <=12 and 1 <=d <=31 :
            return f"{y :04d}-{mo :02d}-{d :02d}"
    return None 

    # ---------------- Extracting metadata from the Internet ----------------
HEADERS ={
"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
"Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
"Accept-Language":"zh-CN,zh;q=0.9,en;q=0.8",
"Connection":"close",
}
TIMEOUT =8 
try :
    from trafilatura import extract_metadata 
    HAVE_TRAF =True 
except Exception :
    HAVE_TRAF =False 

def fetch_meta (url ):
    import requests 
    try :
        r =requests .get (url ,headers =HEADERS ,timeout =TIMEOUT )
        if r .status_code !=200 :
            return None 
        enc =r .encoding or "utf-8"
        try :
            html =r .content .decode (enc ,errors ="ignore")
        except Exception :
            html =r .content .decode ("utf-8",errors ="ignore")
    except Exception :
        return None 
    if HAVE_TRAF :
        try :
            meta =extract_metadata (html )
            if meta and getattr (meta ,"date",None ):
                d =str (meta .date )[:10 ]
                if re .match (r"\d{4}-\d{2}-\d{2}",d ):
                    return d 
        except Exception :
            pass 
    m =re .search (r'<meta[^>]+property=["\']article:published_time["\'][^>]+content=["\']([\d\-]+)',html )
    if m :return m .group (1 )[:10 ]
    m =re .search (r'<meta[^>]+name=["\'](?:pubdate|publishdate|date)["\'][^>]+content=["\']([\d\-]+)',html ,re .I )
    if m :return m .group (1 )[:10 ]
    return extract_date_text (html )

def norm_url (u ):
    if not u :return ""
    return re .split (r"[#?]",u .strip ())[0 ].rstrip ("/").lower ()

    # ---------------- Pass 1: Collection + Replacement Date ----------------
no_date =[]
with open (SRC ,encoding ="utf-8")as f :
    for line in f :
        r =json .loads (line )
        if not r .get ("year_month"):
            no_date .append (r )
print (f"No date record: {len (no_date )}")

filled ,filled_nu ={},{}
src_of ={}# url -> source tag

# 1) Text
c_body =0 
for r in no_date :
    c =r .get ("content","")
    if c .strip ():
        d =extract_date_text (c )
        if d :
            u =r .get ("url")or r .get ("link")or ""
            filled [u ]=d ;filled_nu [norm_url (u )]=d ;src_of [u ]="Regular text"
            c_body +=1 
print (f"Text regularity: {c_body }")

# 2) url path
c_url =0 
for r in no_date :
    u =r .get ("url")or r .get ("link")or ""
    if u in filled :continue 
    d =extract_date_from_url (u )
    if d :
        filled [u ]=d ;filled_nu [norm_url (u )]=d ;src_of [u ]="URL path"
        c_url +=1 
print (f"url path: {c_url }")

# 3) Internet connection
todo =[r for r in no_date if (r .get ("url")or r .get ("link")or "")not in filled ]
print (f"Need to be recaptured: {len (todo )}")
c_net =0 
def worker (r ):
    u =r .get ("url")or r .get ("link")or ""
    return u ,fetch_meta (u )if u else (u ,None )
with ThreadPoolExecutor (max_workers =16 )as ex :
    futs =[ex .submit (worker ,r )for r in todo ]
    done =0 
    for fut in futs :
        u ,d =fut .result ();done +=1 
        if d :
            filled [u ]=d ;filled_nu [norm_url (u )]=d ;src_of [u ]="Re-crawl url";c_net +=1 
        if done %150 ==0 :
            print (f"Recapture {done }/{len (todo )} Obtained {c_net }")
print (f"Reconnect with the Internet: {c_net }")
print (f"Total added up to: {len (filled )} / {len (no_date )}")

# ----------------Pass 2: Rewrite----------------
n_fill =0 
with open (SRC ,encoding ="utf-8")as f ,open (OUT ,"w",encoding ="utf-8")as out :
    for line in f :
        r =json .loads (line )
        if not r .get ("year_month"):
            u =r .get ("url")or r .get ("link")or ""
            d =filled .get (u )or filled_nu .get (norm_url (u ))
            if d :
                r ["date"]=d ;r ["year_month"]=d [:7 ];n_fill +=1 
        out .write (json .dumps (r ,ensure_ascii =False )+"\n")
print (f"Rewriting completed, actual writing date: {n_fill }")

# ----------------Monthly Schedule----------------
month ={}
with open (OUT ,encoding ="utf-8")as f :
    for line in f :
        r =json .loads (line )
        has =1 if (r .get ("has_content","True")=="True"or r .get ("content","").strip ())else 0 
        ym =r .get ("year_month","")or "(无日期)"
        month .setdefault (ym ,Counter ())[has ]+=1 

rows =[]
tot_c =tot_f =0 
for ym in sorted ([k for k in month if k !="(无日期)"]):
    c ,fl =month [ym ][1 ],month [ym ][0 ]
    rows .append ([ym ,c ,fl ,c +fl ]);tot_c +=c ;tot_f +=fl 
if "(无日期)"in month :
    c ,fl =month ["(无日期)"][1 ],month ["(无日期)"][0 ]
    rows .append (["(无日期)",c ,fl ,c +fl ]);tot_c +=c ;tot_f +=fl 
rows .append (["合计",tot_c ,tot_f ,tot_c +tot_f ])
with open (MONTH_CSV ,"w",encoding ="utf-8-sig",newline ="")as f :
    w =csv .writer (f );w .writerow (["月份","有内容条数","失败条数","合计条数"]);w .writerows (rows )
print (f"Monthly table: Content {tot_c } + Failed {tot_f } = {tot_c +tot_f }")

# ---------------- Report ----------------
with open (REPORT ,"w",encoding ="utf-8-sig",newline ="")as f :
    w =csv .writer (f );w .writerow (["url","dataset","补到日期","来源"])
    for r in no_date :
        u =r .get ("url")or r .get ("link")or ""
        d =filled .get (u )or filled_nu .get (norm_url (u ))or ""
        w .writerow ([u ,r .get ("dataset",""),d ,src_of .get (u ,"")])
print ("Report generated")
