# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Summarize all news links that failed to be crawled and build a unified re-crawling queue (removal of duplicates).
Source:
  1) Computer Equipment_Crawling failed.csv (9146) -> Associate Computer Equipment_Merge and remove duplicates.jsonl to get date/title/source
  2) daily_2026-07-30_failures.jsonl (1814) -> url,title
  3) fulltext_failures.jsonl (2628) -> url,title
  4) failures.jsonl (2) -> No article url, skip
At the same time, links that have been successfully concentrated in 0802 are eliminated (no need to re-crawl)."""
import os ,json ,re ,csv ,glob 

def norm_url (u ):
    if not u :return ""
    u =str (u ).strip ()
    u =re .split (r"[#?]",u )[0 ]
    u =u .rstrip ("/").lower ()
    return u 

OUT_DIR =r"D:\study\date\news\111zuixin\合并汇总"
FAIL_DIR =r"D:\study\date\news\111zuixin\失败"
COMPUTE_FAIL =r"D:\study\date\同花顺新闻\合并汇总\计算机设备_爬取失败.csv"
COMPUTE_META =r"D:\study\date\同花顺新闻\合并汇总\计算机设备_合并去重.jsonl"
SUC_0802 =os .path .join (OUT_DIR ,"有内容新闻_合并汇总_0802.jsonl")
QUEUE =os .path .join (OUT_DIR ,"失败重试队列.jsonl")

queue ={}# norm_url -> rec(date,title,source,url,origin)

# 1) Computer device failure + metadata
meta ={}
if os .path .exists (COMPUTE_META ):
    with open (COMPUTE_META ,"r",encoding ="utf-8")as f :
        for line in f :
            try :rec =json .loads (line )
            except :continue 
            nu =norm_url (rec .get ("link",""))
            if nu :meta [nu ]=rec 
n_compute =0 
with open (COMPUTE_FAIL ,"r",encoding ="utf-8-sig",newline ="")as f :
    for row in csv .reader (f ):
        if not row :continue 
        link =row [0 ].strip ()
        if not link .startswith ("http"):continue 
        nu =norm_url (link )
        if not nu :continue 
        m =meta .get (nu ,{})
        rec ={
        "url":link ,
        "title":m .get ("title",""),
        "date":m .get ("date",""),
        "source":m .get ("source",""),
        "origin":"计算机设备",
        }
        queue .setdefault (nu ,rec )
        n_compute +=1 
print ("Computer equipment failure (after deduplication):",len ([k for k in queue ]),"raw:",n_compute )

# 2)+3) jsonl failure file
def add_jsonl (path ,origin ):
    cnt =0 
    with open (path ,"r",encoding ="utf-8")as f :
        for line in f :
            if not line .strip ():continue 
            try :rec =json .loads (line )
            except :continue 
            url =str (rec .get ("url","")).strip ()
            if not url .startswith ("http"):continue 
            nu =norm_url (url )
            if not nu :continue 
            if nu in queue :# If already exists, keep older metadata
                cnt +=1 ;continue 
            queue [nu ]={
            "url":url ,
            "title":rec .get ("title",""),
            "date":"",
            "source":"",
            "origin":origin ,
            }
            cnt +=1 
    print (f"{origin }: {cnt } Join queue")

add_jsonl (os .path .join (FAIL_DIR ,"daily_2026-07-30_failures.jsonl"),"daily_2026-07-30")
add_jsonl (os .path .join (FAIL_DIR ,"fulltext_failures.jsonl"),"fulltext")

print ("Total number of queues after merging and deduplication:",len (queue ))

# Eliminate links already in the 0802 success set
suc =set ()
if os .path .exists (SUC_0802 ):
    with open (SUC_0802 ,"r",encoding ="utf-8")as f :
        for line in f :
            try :rec =json .loads (line )
            except :continue 
            nu =norm_url (rec .get ("url",""))
            if nu :suc .add (nu )
print ("0802 Number of successful centralized links:",len (suc ))
before =len (queue )
queue ={k :v for k ,v in queue .items ()if k not in suc }
print ("After successful elimination, what remains to be crawled:",len (queue ),f"(Remove {before -len (queue )})")

# Attempt to parse date from url (gives jsonl failure completion)
def parse_date_from_url (u ):
    m =re .search (r"(\d{4})[-/](\d{1,2})[-/](\d{1,2})",u )
    if m :return f"{int (m .group (1 )):04d}-{int (m .group (2 )):02d}-{int (m .group (3 )):02d}"
    m =re .search (r"(\d{4})(\d{2})(\d{2})",u )
    if m :return f"{m .group (1 )}-{m .group (2 )}-{m .group (3 )}"
    return ""
filled =0 
for rec in queue .values ():
    if not rec .get ("date"):
        d =parse_date_from_url (rec ["url"])
        if d :
            rec ["date"]=d ;filled +=1 
print ("Complete date from url:",filled )

with open (QUEUE ,"w",encoding ="utf-8")as f :
    for rec in queue .values ():
        f .write (json .dumps (rec ,ensure_ascii =False )+"\n")
print ("OUTPUT queue:",QUEUE ,"Number of items:",len (queue ))
