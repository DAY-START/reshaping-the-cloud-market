# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Summarize the truly “news content” articles from various sources under 111zuixin into one folder.
And generate monthly statistical tables (number of news items per month).

Selection rules (written in summary/processing instructions.txt):
  There is a non-empty title and the valid date can be parsed and (the text is not empty or there is a source or there is a link)
Cross-file deduplication key: (normalized title, year, month and day)

Description:
  - unified already contains all the contents of datelab_raw, so datelab_raw is skipped to avoid duplication.
  - Flush supplement.csv is a subset of Flush crawler summary.csv, so only the "summary" is taken."""

import os 
import re 
import json 
import csv 
from datetime import datetime 
from collections import defaultdict ,Counter 

BASE =r"D:\study\date\news\111zuixin"
OUT_DIR =os .path .join (BASE ,"汇总")
os .makedirs (OUT_DIR ,exist_ok =True )

# (source tag, path, type, field mapping)
# Field mapping: original field name corresponding to title/date/source/url/content; content=None means no text column
CONFIG =[
("datelab_unified",
os .path .join (BASE ,"unified","AI_Computing_News_Unified_20210701_20260630.jsonl"),
"jsonl",{"title":"title","date":"date","source":"source","url":"url","content":"content"}),
("ths_fulltext_dedup",
os .path .join (BASE ,"ths","AI_Computing_News_THS_Fulltext_Deduplicated.jsonl"),
"jsonl",{"title":"title","date":"date","source":"source","url":"url","content":"content"}),
("ths_daily",
os .path .join (BASE ,"ths","daily_2026-07-30.jsonl"),
"jsonl",{"title":"title","date":"date","source":"source","url":"url","content":"content"}),
("ths_archive",
os .path .join (BASE ,"ths","AI_Computing_News_THS_20210701_20260630.jsonl"),
"jsonl",{"title":"title","date":"date","source":"source","url":"url","content":"content"}),
("workbuddy",
os .path .join (BASE ,"workbuddy","workbuddyai_compute_news_2023_2026.jsonl"),
"jsonl",{"title":"title","date":"date","source":"source","url":"url","content":"content"}),
("yuanbao",
os .path .join (BASE ,"yuanbao","yuanbaoai_computing_power_news.jsonl"),
"jsonl",{"title":"title","date":"date","source":"source","url":"url","content":"content"}),
("gpt_verified",
os .path .join (BASE ,"gpt_verified","gptverified_seed_zh.jsonl"),
"jsonl",{"title":"title","date":"news_date","source":"source","url":"link","content":"content"}),
("crawler",
os .path .join (BASE ,"crawler","AI_Computing_News_Crawler_20230401_20260630.jsonl"),
"jsonl",{"title":"title","date":"date","source":"source","url":"url","content":"content"}),
("historical_web",
os .path .join (BASE ,"historical_web","AI_Computing_Historical_Web_News_20210701_20260630.jsonl"),
"jsonl",{"title":"title","date":"date","source":"source","url":"url","content":"content"}),
("kimi",
os .path .join (BASE ,"kimi","kimiAI算力新闻数据集_2023-2026.json"),
"json",{"title":"title","date":"date","source":"source","url":"url","content":"summary"}),
("doubao",
os .path .join (BASE ,"doubao","doubao算力财经新闻数据集（2026年6-7月，3033条）.jsonl"),
"jsonl",{"title":"title","date":"date","source":"source","url":"url","content":"content"}),
("tonghuashun",
os .path .join (BASE ,"tonghuashun","同花顺爬虫汇总.csv"),
"csv",{"title":"新闻标题","date":"新闻日期","source":"新闻来源","url":"原文链接","content":None }),
]

# Skip (to avoid duplication/corruption): datelab_raw (included by unified), flush complement (aggregated subset)
SKIPPED_NOTE =[
("datelab_raw/AI_Computing_News_Raw_after_20210701.jsonl","与 unified 内容重复(unified 已包含)，跳过"),
("tonghuashun/同花顺补充.csv","是同花顺爬虫汇总的子集，跳过以免重复计数"),
]


def parse_date (raw ):
    if raw is None :
        return None ,None 
    s =str (raw ).strip ()
    if not s :
        return None ,None 
        # Pure number -> timestamp (milliseconds or seconds)
    if s .isdigit ():
        n =int (s )
        try :
            if n >1e11 :
                dt =datetime .fromtimestamp (n /1000 )
            elif n >1e9 :
                dt =datetime .fromtimestamp (n )
            else :
                return None ,None 
            return dt .strftime ("%Y-%m-%d"),dt .strftime ("%Y-%m")
        except Exception :
            return None ,None 
    m =re .match (r'(\d{4})[-/](\d{1,2})[-/](\d{1,2})',s )
    if m :
        y ,mo ,d =m .groups ()
        try :
            dt =datetime (int (y ),int (mo ),int (d ))
            return dt .strftime ("%Y-%m-%d"),f"{y }-{int (mo ):02d}"
        except Exception :
            return None ,None 
    return None ,None 


def norm_key (title ):
    if not title :
        return ""
    return re .sub (r'\s+','',str (title )).lower ()


def read_records (path ,ftype ,mapping ):
    """generate (rec_dict, date_raw, title_raw, source_raw, url_raw, content_raw)"""
    if ftype =="csv":
        with open (path ,encoding ="utf-8-sig",newline ="")as fh :
            reader =csv .DictReader (fh )
            for row in reader :
                yield row 
    elif ftype =="json":
        with open (path ,encoding ="utf-8")as fh :
            data =json .load (fh )
        for row in data :
            yield row 
    else :# jsonl
        with open (path ,encoding ="utf-8")as fh :
            for line in fh :
                line =line .strip ()
                if not line :
                    continue 
                try :
                    yield json .loads (line )
                except Exception :
                    continue 


def main ():
    out_jsonl =os .path .join (OUT_DIR ,"新闻汇总_有内容.jsonl")
    out_monthly =os .path .join (OUT_DIR ,"月度新闻统计表.csv")
    out_source =os .path .join (OUT_DIR ,"数据集来源统计.csv")
    out_note =os .path .join (OUT_DIR ,"处理说明.txt")

    seen =set ()
    monthly =Counter ()# ym -> count
    src_stats ={}# label -> [read, qualified, kept]
    total_kept =0 

    with open (out_jsonl ,"w",encoding ="utf-8")as fout :
        for label ,path ,ftype ,mp in CONFIG :
            src_stats [label ]=[0 ,0 ,0 ]
            if not os .path .isfile (path ):
                print (f"[Missing] {label }: {path }")
                continue 
            for rec in read_records (path ,ftype ,mp ):
                src_stats [label ][0 ]+=1 
                title =(rec .get (mp ["title"])or "").strip ()if mp .get ("title")else ""
                date_raw =rec .get (mp ["date"])if mp .get ("date")else None 
                source =(rec .get (mp ["source"])or "").strip ()if mp .get ("source")else ""
                url =(rec .get (mp ["url"])or "").strip ()if mp .get ("url")else ""
                content =(rec .get (mp ["content"])or "").strip ()if mp .get ("content")else ""
                date_iso ,ym =parse_date (date_raw )

                # Selection rules
                content_ok =len (content )>=10 
                source_ok =len (source )>0 
                url_ok =len (url )>0 
                if title and ym and (content_ok or source_ok or url_ok ):
                    src_stats [label ][1 ]+=1 
                    key =(norm_key (title ),date_iso or ym )
                    if key in seen :
                        continue 
                    seen .add (key )
                    src_stats [label ][2 ]+=1 
                    total_kept +=1 
                    monthly [ym ]+=1 
                    out ={
                    "date":date_iso or "",
                    "year_month":ym ,
                    "title":title ,
                    "source":source ,
                    "url":url ,
                    "content":content ,
                    "dataset":label ,
                    }
                    fout .write (json .dumps (out ,ensure_ascii =False )+"\n")

                    # Write monthly statistics
    with open (out_monthly ,"w",encoding ="utf-8-sig",newline ="")as f :
        w =csv .writer (f )
        w .writerow (["年月","新闻条数"])
        for ym in sorted (monthly .keys ()):
            w .writerow ([ym ,monthly [ym ]])
        w .writerow (["合计",sum (monthly .values ())])

        # Write source statistics
    with open (out_source ,"w",encoding ="utf-8-sig",newline ="")as f :
        w =csv .writer (f )
        w .writerow (["来源标签","读取条数","符合入选条件","去重后入选"])
        for label ,(rd ,q ,k )in src_stats .items ():
            w .writerow ([label ,rd ,q ,k ])

            # write description
    with open (out_note ,"w",encoding ="utf-8")as f :
        f .write ("新闻汇总处理说明\n")
        f .write ("="*40 +"\n\n")
        f .write ("入选规则：\n")
        f .write ("  1) 标题非空；\n")
        f .write ("  2) 能解析出有效日期(YYYY-MM)；\n")
        f .write ("  3) 满足以下任一项：正文非空(>=10字) / 有来源 / 有链接。\n\n")
        f .write ("去重规则：跨文件按 (规范化标题, 日期) 去重。\n\n")
        f .write ("跳过文件：\n")
        for p ,reason in SKIPPED_NOTE :
            f .write (f"  - {p }：{reason }\n")
        f .write (f"\nFinal total number of retained articles: {total_kept }\n")
        f .write (f"Number of months covered: {len (monthly )} \n")

    print ("="*50 )
    print (f"Output directory: {OUT_DIR }")
    print (f"Total number of articles retained: {total_kept }")
    print (f"Number of months covered: {len (monthly )}")
    print (f"Summary file: {out_jsonl }")
    print (f"Monthly Statistics: {out_monthly }")
    print (f"Source statistics: {out_source }")
    print ("\n各来源(读取/入选/去重后):")
    for label ,(rd ,q ,k )in src_stats .items ():
        print (f"  {label :18s} {rd :>8d} / {q :>8d} / {k :>8d}")
        # Print monthly preview of first few rows
    print ("\n月度统计(前15个月):")
    for ym in sorted (monthly .keys ())[:15 ]:
        print (f"  {ym }: {monthly [ym ]}")


if __name__ =="__main__":
    main ()
