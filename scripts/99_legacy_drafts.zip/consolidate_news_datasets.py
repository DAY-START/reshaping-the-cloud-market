# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Unify the scattered news data sets (core data sets) on drive D into
D:\\study\\date\\news\\111zuixin\\, press the source molecule folder, copy and retain the original file.

Strategy (based on user confirmation):
  -Transportation method: copy (retain original file)
  - Classification structure: by source molecule folder
  - File Scope: Core Dataset (excludes scripts/logs/statistics reports/tests and obvious duplicate copies)"""

import os 
import shutil 
import csv 
from datetime import datetime 

DEST_ROOT =r"D:\study\date\news\111zuixin"

# (subfolder name, [list of absolute paths to source files]) - core dataset only
INCLUDE ={
"workbuddy":[
r"D:\study\date\ai_computing_news\workbuddyai_compute_news_2023_2026.jsonl",
],
"yuanbao":[
r"D:\study\date\ai_computing_news\yuanbaoai_computing_power_news.jsonl",
],
"gpt_verified":[
r"D:\study\date\ai_computing_news\gptverified_seed_zh.jsonl",
],
"crawler":[
r"D:\study\date\ai_computing_news\crawler_output\AI_Computing_News_Crawler_20230401_20260630.jsonl",
],
"historical_web":[
r"D:\study\date\ai_computing_news\ai_computing_web_collector\historical_ai_news_output\AI_Computing_Historical_Web_News_20210701_20260630.jsonl",
],
"ths":[
r"D:\study\date\ai_computing_news\ths_api_download\AI_Computing_News_THS_Fulltext_Deduplicated.jsonl",
r"D:\study\date\ai_computing_news\ths_api_download\daily_2026-07-30.jsonl",
r"D:\date新闻数据集\AI_Computing_News_THS_20210701_20260630.jsonl",
],
"kimi":[
r"D:\study\date\ai_computing_news\kimiAI算力新闻数据集_2023-2026.json",
],
"doubao":[
r"D:\study\date\ai_computing_news\doubao算力财经新闻数据集（2026年6-7月，3033条）.jsonl",
],
"datelab_raw":[
r"D:\study\date\ai_computing_news\AI_Computing_News_Raw_after_20210701.jsonl",
],
"unified":[
r"D:\study\date\ai_computing_news\AI_Computing_News_Unified_20210701_20260630.jsonl",
],
"tonghuashun":[
r"D:\study\date\news\tonghuashunpachong\同花顺爬虫汇总.csv",
r"D:\study\date\news\tonghuashunpachong\同花顺补充.csv",
],
}

# Explicitly skipped files and reasons (for records only, will not be copied if not included in INCLUDE)
SKIPPED =[
(r"D:\study\date\ai_computing_news\yuanbao1ai_computing_power_news.jsonl","重复(yuanbao 变体)"),
(r"D:\study\date\ai_computing_news\crawler_output\AI_Computing_News_Crawler_TEST.jsonl","测试副本"),
(r"D:\study\date\ai_computing_news\ai_computing_web_collector\web_ai_news_output\AI_Computing_Web_News_20210701_20260630.jsonl","空文件(0字节)"),
(r"D:\study\date\ai_computing_news\ths_api_download\AI_Computing_News_THS_Fulltext.jsonl","中间产物(已被 Fulltext_Deduplicated 替代)"),
(r"D:\study\date\ai_computing_news\ths_api_download\AI_Computing_News_THS_20210701_20260630.jsonl","中间产物(已有去重版)"),
(r"D:\date新闻数据集\daily_2026-07-29.jsonl","重复(与 daily_2026-07-30 同日批次)"),
(r"D:\ai_compute_zh_collector\verified_seed_zh.jsonl","重复(gpt_verified 同内容)"),
(r"D:\study\date\news\data\kimiAI算力新闻数据集_2023-2026.json","重复(与 ai_computing_news/kimi 同文件)"),
(r"D:\study\test1\001_download_ai_computing_news_202107_202607.csv","实验副本(重复)"),
(r"D:\study\test1\001_download_ai_computing_news_202107_202607.jsonl","实验副本(重复)"),
(r"D:\study\test1\month_news_avg_gcs.csv","统计报告(非数据集)"),
(r"D:\study\test1\news_dataset_2018_to_2023.jsonl","实验副本(重复)"),
(r"D:\study\test2\001_download_ai_computing_news_202107_202607.csv","实验副本(重复)"),
(r"D:\study\test2\001_download_ai_computing_news_202107_202607.jsonl","实验副本(重复)"),
(r"D:\study\test2\ai_computing_news_202107_202607.jsonl","实验副本(重复)"),
(r"D:\study\test2\news_dataset_2018_to_2023.jsonl","实验副本(重复)"),
(r"D:\study\date\ai_computing_news\AI_Computing_News_Month_Distribution.csv","统计报告(非数据集)"),
(r"D:\study\date\ai_computing_news\AI_Computing_News_Year_Distribution.csv","统计报告(非数据集)"),
(r"D:\study\date\news\reports\dataset_catalog.csv","统计报告(非数据集)"),
(r"D:\study\date\news\reports\complete_monthly_counts.csv","统计报告(非数据集)"),
(r"D:\study\date\news\reports\missing_fields_summary.csv","统计报告(非数据集)"),
(r"D:\study\date\news\reports\news_monthly_counts_by_file.csv","统计报告(非数据集)"),
(r"D:\study\date\news\reports\news_monthly_statistics_summary.csv","统计报告(非数据集)"),
(r"D:\date新闻数据集\download.log","脚本日志(非数据集)"),
(r"D:\date新闻数据集\download_ai_computing_news.py","脚本(非数据集)"),
(r"D:\date新闻数据集\download_index.sqlite3","索引数据库(非数据集)"),
(r"D:\date新闻数据集\download_state.json","状态文件(非数据集)"),
(r"D:\date新闻数据集\failures.jsonl","失败记录(非数据集)"),
(r"D:\ai_compute_zh_collector\collect_ai_compute_news_zh.py","脚本(非数据集)"),
(r"D:\软件\python\项目\news_work\final_output\compute_news_final.jsonl","catalog 记录但文件不存在(已删除/路径变更)"),
]


def human_readable (num_bytes ):
    size =float (num_bytes )
    for unit in ["B","KB","MB","GB","TB"]:
        if size <1024.0 :
            return f"{size :.2f} {unit }"
        size /=1024.0 
    return f"{size :.2f} PB"


def main ():
    os .makedirs (DEST_ROOT ,exist_ok =True )
    manifest_rows =[]# Records copied to 111zuixin
    copy_errors =[]

    total_files =0 
    total_bytes =0 

    for subfolder ,src_list in INCLUDE .items ():
        dest_dir =os .path .join (DEST_ROOT ,subfolder )
        os .makedirs (dest_dir ,exist_ok =True )
        for src in src_list :
            if not os .path .isfile (src ):
                copy_errors .append ((src ,"源文件不存在"))
                print (f"[Skip] Source does not exist: {src }")
                continue 
            fname =os .path .basename (src )
            dest =os .path .join (dest_dir ,fname )
            size =os .path .getsize (src )
            try :
                shutil .copy2 (src ,dest )
                total_files +=1 
                total_bytes +=size 
                manifest_rows .append ([subfolder ,fname ,src ,dest ,human_readable (size ),"OK"])
                print (f"[Copy] {subfolder }/ {fname } ({human_readable (size )})")
            except Exception as e :
                copy_errors .append ((src ,str (e )))
                manifest_rows .append ([subfolder ,fname ,src ,dest ,human_readable (size ),f"ERR: {e }"])
                print (f"[Error] {src } -> {dest }: {e }")

                # write list
    manifest_path =os .path .join (DEST_ROOT ,"归集清单.csv")
    with open (manifest_path ,"w",encoding ="utf-8-sig",newline ="")as f :
        w =csv .writer (f )
        w .writerow (["目标子文件夹","文件名","原路径","新路径","大小","状态"])
        for row in manifest_rows :
            w .writerow (row )
        for src ,reason in SKIPPED :
            w .writerow (["(跳过)",os .path .basename (src ),src ,"","",f"Skip: {reason }"])
        if copy_errors :
            for src ,err in copy_errors :
                w .writerow (["(错误)",os .path .basename (src ),src ,"","",f"Error: {err }"])

    print ("\n==================== 归集完成 ====================")
    print (f"Target directory: {DEST_ROOT }")
    print (f"Number of successfully copied files: {total_files }")
    print (f"Total copy size: {human_readable (total_bytes )}")
    print (f"Number of explicitly skipped files: {len (SKIPPED )}")
    print (f"Number of copy errors: {len (copy_errors )}")
    print (f"Manifest file: {manifest_path }")


if __name__ =="__main__":
    main ()
