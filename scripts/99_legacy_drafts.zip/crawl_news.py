# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

import csv ,json ,re ,os ,sys ,time ,argparse ,threading ,random 
from concurrent .futures import ThreadPoolExecutor ,as_completed 
import requests ,trafilatura 

csv .field_size_limit (10_000_000 )

BASE =r"D:\study\date\news"
SUP =os .path .join (BASE ,"tonghuashunpachong","同花顺补充.csv")
SUP_OUT =os .path .join (BASE ,"tonghuashunpachong","同花顺补充_带内容.csv")
B1 =os .path .join (BASE ,"tonghuashunpachong","crawl_batch1.jsonl")
B1_FAILED =os .path .join (BASE ,"tonghuashunpachong","crawl_batch1_failed.jsonl")
B2 =os .path .join (BASE ,"tonghuashunpachong","crawl_batch2.jsonl")
OLD_SUMMARY =os .path .join (BASE ,"111zuixin","汇总","新闻汇总_有内容.jsonl")

UAS =[
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15",
]
HEADERS ={"User-Agent":UAS [0 ],"Accept":"text/html,application/xhtml+xml,*/*","Accept-Language":"zh-CN,zh;q=0.9"}

TARGET_MONTHS =set ()
for m in (4 ,5 ,6 ):TARGET_MONTHS .add (f"2023-{m :02d}")
for y in (2024 ,2025 ,2026 ):
    for m in range (1 ,13 ):TARGET_MONTHS .add (f"{y }-{m :02d}")
MONTH_CAP =5000 # Batch 2 Skip Threshold: If the number of content items in a certain month (after Batch 1) is >= this value, no additional content will be added.
MAX_WORKERS =48 # Number of concurrent threads
REQ_TIMEOUT =10 # Request timeout (seconds)
RETRY =1 # Number of failed retries

lock =threading .Lock ()
seen_urls =set ()

def norm_url (u ):
    u =(u or "").strip ()
    u =re .sub (r"[#?].*$","",u )
    u =re .sub (r"/$","",u )
    return u .lower ()

def ym_of (s ):
    if not s :return None 
    m =re .match (r"(\d{4}-\d{2})",str (s ).strip ())
    return m .group (1 )if m else None 

def load_done (path ):
    done =set ()
    if os .path .exists (path ):
        with open (path ,encoding ="utf-8")as f :
            for line in f :
                try :r =json .loads (line )
                except :continue 
                if r .get ("content"):done .add (norm_url (r .get ("url","")))
    return done 

def fetch_one (url ):
    last =None 
    for i in range (RETRY ):
        h =HEADERS .copy ();h ["User-Agent"]=UAS [i %len (UAS )]
        try :
            r =requests .get (url ,headers =h ,timeout =REQ_TIMEOUT )
            if r .status_code !=200 :
                last =f"http{r .status_code }"
                if r .status_code in (403 ,429 ,503 ,500 ):time .sleep (0.5 );continue 
                return None ,last 
            raw =r .content 
            txt =trafilatura .extract (raw ,include_comments =False ,include_tables =False )
            return (txt .strip ()if txt else ""),None 
        except Exception as e :
            last =f"{type (e ).__name__ }"
            time .sleep (0.3 )
    return None ,last 

def worker (item ):
    url =item ["url"];nu =norm_url (url )
    with lock :
        if nu in seen_urls :return None 
        seen_urls .add (nu )
    time .sleep (0.1 +0.3 *random .random ())
    content ,reason =fetch_one (url )
    if content is None :
        with lock :
            with open (B1_FAILED ,"a",encoding ="utf-8")as ff :
                ff .write (json .dumps ({"url":url ,"reason":reason ,"date":item .get ("date","")},ensure_ascii =False )+"\n")
        return None 
    return {**item ,"content":content ,"crawled":True }

def run_batch (items ,out_path ,sample =None ):
    if sample :items =items [:sample ]
    done =load_done (out_path )
    with lock :seen_urls .update (done )
    todo =[it for it in items if norm_url (it ["url"])not in done ]
    print (f"To be climbed: {len (todo )} (Completed and skipped {len (items )-len (todo )})")
    ok =0 ;empty =0 ;fail =0 
    with ThreadPoolExecutor (max_workers =MAX_WORKERS )as ex ,open (out_path ,"a",encoding ="utf-8")as fout :
        futs ={ex .submit (worker ,it ):it for it in todo }
        for fut in as_completed (futs ):
            res =fut .result ()
            if res is None :fail +=1 ;continue 
            fout .write (json .dumps (res ,ensure_ascii =False )+"\n");fout .flush ()
            if len (res ["content"])>=15 :ok +=1 
            else :empty +=1 
    print (f"Completion: With text={ok } Empty text={empty } Failed={fail }")
    return ok ,empty ,fail 

def batch1 (sample =None ):
    print ("=== 批1：爬取 同花顺补充.csv (全部目标月份 url) ===")
    items =[]
    with open (SUP ,encoding ="utf-8-sig")as f :
        for row in csv .DictReader (f ):
            m =ym_of (row .get ("新闻日期",""))
            if m not in TARGET_MONTHS :continue 
            items .append ({"date":row .get ("新闻日期",""),"title":row .get ("新闻标题",""),
            "source":row .get ("新闻来源",""),"url":row .get ("原文链接",""),"dataset":"Flush Supplement"})
    print (f"Total number of target month urls: {len (items )}")
    run_batch (items ,B1 ,sample =sample )
    # Write out csv with content
    by_url ={}
    if os .path .exists (B1 ):
        with open (B1 ,encoding ="utf-8")as f :
            for line in f :
                r =json .loads (line );by_url [norm_url (r ["url"])]=r .get ("content","")
                # Write out csv with content (retry when file is occupied)
    last_err =None 
    for attempt in range (30 ):
        try :
            with open (SUP ,encoding ="utf-8-sig")as f ,open (SUP_OUT ,"w",encoding ="utf-8-sig",newline ="")as fo :
                rd =csv .DictReader (f );w =csv .DictWriter (fo ,fieldnames =list (rd .fieldnames )+["新闻内容"],quoting =csv .QUOTE_ALL )
                w .writeheader ()
                for row in rd :
                    c =by_url .get (norm_url (row .get ("原文链接","")),"")
                    row ["新闻内容"]=c .replace ("\r"," ").replace ("\n"," ")
                    w .writerow (row )
            break 
        except PermissionError as e :
            last_err =e 
            print (f"[CSV write] The file is occupied, try again in 3 seconds ({attempt +1 }/30)...")
            time .sleep (3 )
    else :
        raise last_err 
    print (f"Already written Flush Supplement_with content.csv (including text {sum (1 for v in by_url .values ()if len (v )>=15 )} items)")
    from collections import Counter 
    mc =Counter ()
    with open (B1 ,encoding ="utf-8")as f :
        for line in f :
            r =json .loads (line )
            if len (r .get ("content",""))>=15 :
                mm =ym_of (r .get ("date",""))
                if mm :mc [mm ]+=1 
    return mc 

def mm_cap (mm ,cap ):
    return cap .get (mm ,0 )>=MONTH_CAP 

def batch2 (month_cap_count ,sample =None ):
    print ("=== Batch 2: Crawling summary (old) only records with URLs and months that have not exceeded the threshold ===")
    b1_done =load_done (B1 )
    items =[]
    with open (OLD_SUMMARY ,encoding ="utf-8")as f :
        for line in f :
            r =json .loads (line )
            if len ((r .get ("content","")or "").strip ())>=15 :continue 
            nu =norm_url (r .get ("url",""))
            if nu in b1_done :continue 
            mm =ym_of (r .get ("date",""))
            if mm and mm_cap (mm ,month_cap_count ):continue 
            items .append ({"date":r .get ("date",""),"title":r .get ("title",""),
            "source":r .get ("source",""),"url":r .get ("url",""),"dataset":r .get ("dataset","")})
    print (f"Summary waiting to be crawled (remaining only url and not big month): {len (items )}")
    if not items :return 
    run_batch (items ,B2 ,sample =sample )

if __name__ =="__main__":
    ap =argparse .ArgumentParser ()
    ap .add_argument ("--sample",type =int ,default =None )
    ap .add_argument ("--batch2",action ="store_true")
    a =ap .parse_args ()
    t0 =time .time ()
    mc =batch1 (sample =a .sample )
    print ("Batch 1 Valid number of entries per month:",dict (sorted (mc .items ())))
    if a .batch2 :
        batch2 (mc ,sample =a .sample )
    print (f"\nTotal time taken: {time .time ()-t0 :.1f}s")
