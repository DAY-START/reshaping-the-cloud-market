# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Improved recrawl: Retry with real browser request headers. Links in failed retry_still-failed.csv."""
import json ,csv ,os ,re ,time ,sys 
from concurrent .futures import ThreadPoolExecutor ,as_completed 
from urllib .parse import urlparse 

import requests 
import trafilatura 

BASE =r"D:\study\date\news\111zuixin\合并汇总"
IN_CSV =os .path .join (BASE ,"失败重试_仍失败.csv")
OUT_OK =os .path .join (BASE ,"失败重试2_带内容.jsonl")
OUT_FAIL =os .path .join (BASE ,"失败重试2_仍失败.csv")
PROGRESS =os .path .join (BASE ,"retry2_progress.txt")

MAX_WORKERS =48 
TIMEOUT =20 # Longer than the previous round, dealing with timeout classes
RETRIES =2 # Retry on 5xx/timeout/connection errors
HEADERS ={
"User-Agent":("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
"(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"),
"Accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,"
"image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
"Accept-Language":"zh-CN,zh;q=0.9,en;q=0.8",
"Accept-Encoding":"gzip, deflate, br",
"Connection":"keep-alive",
"Upgrade-Insecure-Requests":"1",
"Sec-Fetch-Dest":"document",
"Sec-Fetch-Mode":"navigate",
"Sec-Fetch-Site":"none",
"Sec-Fetch-User":"?1",
}

def norm_url (u ):
    if not u :
        return ""
    u =u .strip ()
    u =re .split (r"[#?]",u )[0 ]
    u =u .rstrip ("/")
    return u .lower ()

def is_garbled (text ):
    if not text :
        return True 
    return ("Ã"in text )or ("Â"in text )or ("\ufffd"in text and len (text )<50 )

def fetch (url ):
    last =None 
    for attempt in range (RETRIES +1 ):
        try :
            r =requests .get (url ,headers =HEADERS ,timeout =TIMEOUT )
            if r .status_code !=200 :
                last =f"HTTP {r .status_code }"
                # Retry only for 5xx/429
                if r .status_code in (429 ,500 ,502 ,503 ,504 ,567 ,514 )and attempt <RETRIES :
                    time .sleep (1.0 )
                    continue 
                return None ,last 
            if not r .content or len (r .content )<200 :
                last ="empty body"
                if attempt <RETRIES :
                    continue 
                return None ,last 
            return r .content ,None 
        except Exception as e :
            last =f"{type (e ).__name__ }: {e }"
            # Retry on timeout/connection error
            if attempt <RETRIES and ("Timeout"in type (e ).__name__ or "Connection"in type (e ).__name__ ):
                time .sleep (0.8 )
                continue 
            return None ,last 
    return None ,last 

def extract (raw_bytes ):
    try :
        doc =trafilatura .extract (raw_bytes ,
        include_comments =False ,include_tables =False ,
        favor_precision =True )
        if doc :
            doc =re .sub (r"\n{3,}","\n\n",doc ).strip ()
            if len (doc )>=15 and not is_garbled (doc ):
                return doc 
    except Exception :
        pass 
    return ""

def main ():
    import os as _os 
    in_csv =_os .environ .get ("CRAWL_IN",IN_CSV )
    limit =int (_os .environ .get ("CRAWL_LIMIT","0"))or 0 
    # Resume crawling from breakpoint: skip successful/failed URLs
    done =set ()
    for pf in (OUT_OK ,OUT_FAIL ):
        if _os .path .exists (pf ):
            try :
                with open (pf ,encoding ="utf-8"if pf .endswith (".jsonl")else "utf-8-sig")as fh :
                    for line in fh :
                        line =line .strip ()
                        if not line :
                            continue 
                        if pf .endswith (".jsonl"):
                            try :
                                done .add (norm_url (json .loads (line ).get ("url","")))
                            except Exception :
                                pass 
                        else :
                            try :
                                done .add (norm_url (line .split (",",1 )[0 ].strip ().strip ('"')))
                            except Exception :
                                pass 
            except Exception :
                pass 

    records =[]
    with open (in_csv ,encoding ="utf-8-sig")as f :
        for row in csv .reader (f ):
            if not row or not row [0 ].strip ():
                continue 
            url =row [0 ].strip ()
            if norm_url (url )in done :
                continue 
            title =row [2 ]if len (row )>2 else ""
            date =row [3 ]if len (row )>3 else ""
            source =row [4 ]if len (row )>4 else ""
            ds =row [5 ]if len (row )>5 else ""
            records .append ({"url":url ,"title":title ,"date":date ,
            "source":source ,"dataset":ds })
            if limit and len (records )>=limit :
                break 
    print (f"load {len (records )} records (input={in_csv })")

    out_ok =open (OUT_OK ,"w",encoding ="utf-8")
    out_fail =open (OUT_FAIL ,"w",encoding ="utf-8-sig",newline ="")
    fw =csv .writer (out_fail )
    fw .writerow (["url","reason","title","date","source","dataset"])

    ok =0 
    fail =0 
    done =0 
    total =len (records )
    t0 =time .time ()

    def worker (rec ):
        raw ,reason =fetch (rec ["url"])
        if raw is None :
            return rec ,reason ,None 
        content =extract (raw )
        if not content :
            return rec ,"no content extracted(improved)",None 
        return rec ,None ,content 

    with ThreadPoolExecutor (max_workers =MAX_WORKERS )as ex :
        futs =[ex .submit (worker ,r )for r in records ]
        for fut in as_completed (futs ):
            rec ,reason ,content =fut .result ()
            if content :
                out_ok .write (json .dumps ({
                "date":rec ["date"],"title":rec ["title"],
                "source":rec ["source"],"url":rec ["url"],
                "content":content ,"dataset":rec ["dataset"]or "Failed retry to make up for 2",
                },ensure_ascii =False )+"\n")
                out_ok .flush ()
                ok +=1 
            else :
                fw .writerow ([rec ["url"],reason ,rec ["title"],rec ["date"],
                rec ["source"],rec ["dataset"]])
                fail +=1 
            done +=1 
            if done %1000 ==0 :
                rate =done /(time .time ()-t0 )
                eta =(total -done )/rate /60 if rate else 0 
                with open (PROGRESS ,"w",encoding ="utf-8")as pf :
                    pf .write (f"[{time .strftime ('%H:%M:%S')}] processed={done }/{total } "
                    f"ok={ok } fail={fail } rate={rate :.2f}/s ETA={eta :.1f}min\n")

    out_ok .close ()
    out_fail .close ()
    print (f"DONE. ok={ok } fail={fail } total={total }")

if __name__ =="__main__":
    main ()
