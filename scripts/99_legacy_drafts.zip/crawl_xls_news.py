# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Crawl the original text link in Computer Equipment_Merge and Remove Duplication.jsonl to obtain the news text.
Resume crawling from breakpoint: all successful/failed links will be skipped.
requests + trafilatura, 48 concurrency, 10s timeout, 1 retry."""
import os ,json ,re ,csv ,time ,sys ,threading 
from concurrent .futures import ThreadPoolExecutor ,as_completed 

import requests 
import trafilatura 

OUT_DIR =r"D:\study\date\同花顺新闻\合并汇总"
IN_JSONL =os .path .join (OUT_DIR ,"计算机设备_合并去重.jsonl")
OUT_JSONL =os .path .join (OUT_DIR ,"计算机设备_合并去重_带内容.jsonl")
FAIL_CSV =os .path .join (OUT_DIR ,"计算机设备_爬取失败.csv")
PROGRESS =os .path .join (OUT_DIR ,"crawl_progress.txt")

MAX_WORKERS =48 
TIMEOUT =10 
RETRIES =1 
HEADERS ={
"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
"(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
"Accept-Language":"zh-CN,zh;q=0.9",
}

def norm_url (u ):
    if not u :return ""
    u =str (u ).strip ()
    u =re .split (r"[#?]",u )[0 ]
    u =u .rstrip ("/").lower ()
    return u 

def fetch (url ):
    last =None 
    for attempt in range (RETRIES +1 ):
        try :
            r =requests .get (url ,headers =HEADERS ,timeout =TIMEOUT )
            if r .status_code !=200 :
                last =f"HTTP {r .status_code }"
                if attempt <RETRIES :
                    continue 
                return None ,last 
                # Use raw bytes and hand it over to trafilatura for encoding detection (automatically handles GBK/GB2312)
            raw =r .content 
            if not raw or len (raw )<200 :
                last ="empty body"
                if attempt <RETRIES :
                    continue 
                return None ,last 
            return raw ,None 
        except Exception as e :
            last =f"{type (e ).__name__ }: {e }"
            if attempt <RETRIES :
                time .sleep (0.5 )
                continue 
            return None ,last 
    return None ,last 

def extract (raw_bytes ):
# First hand it over directly to trafilatura to detect the encoding
    try :
        doc =trafilatura .extract (raw_bytes ,include_comments =False ,include_tables =False )
        if doc :
            doc =re .sub (r"\n{3,}","\n\n",doc ).strip ()
            # If obvious garbled characters still appear (GBK is treated as UTF-8), use apparent_encoding to fall back
            if is_garbled (doc ):
                txt =try_decode (raw_bytes )
                if txt :
                    doc2 =trafilatura .extract (txt ,include_comments =False ,include_tables =False )
                    if doc2 and not is_garbled (doc2 ):
                        doc =re .sub (r"\n{3,}","\n\n",doc2 ).strip ()
            return doc 
    except Exception :
        pass 
    return ""

def is_garbled (s ):
# Contains replacement characters, or a large number of consecutive latin1 double-byte fake Chinese characters
    if "\ufffd"in s :
        return True 
    cnt =sum (1 for ch in s [:200 ]if 0x80 <=ord (ch )<=0xFF )
    return len (s )>0 and cnt /max (1 ,len (s [:200 ]))>0.25 

def try_decode (raw ):
    try :
        import chardet 
        enc =chardet .detect (raw [:50000 ]).get ("encoding")
        if enc :
            return raw .decode (enc ,errors ="ignore")
    except Exception :
        pass 
    for enc in ("utf-8","gb18030","gbk"):
        try :
            return raw .decode (enc ,errors ="ignore")
        except Exception :
            continue 
    return None 

    # Load processed links (continue crawling)
done =set ()
if os .path .exists (OUT_JSONL ):
    with open (OUT_JSONL ,"r",encoding ="utf-8")as f :
        for line in f :
            try :
                rec =json .loads (line )
                done .add (norm_url (rec .get ("link","")))
            except Exception :
                pass 
failed =set ()
if os .path .exists (FAIL_CSV ):
    with open (FAIL_CSV ,"r",encoding ="utf-8-sig",newline ="")as f :
        for row in csv .reader (f ):
            if row :
                failed .add (norm_url (row [0 ]))
print (f"already done(success): {len (done )}, failed: {len (failed )}")

# Read to be crawled
tasks =[]
seen =set ()
with open (IN_JSONL ,"r",encoding ="utf-8")as f :
    for line in f :
        try :
            rec =json .loads (line )
        except Exception :
            continue 
        nu =norm_url (rec .get ("link",""))
        if not nu :
            continue 
        if nu in done or nu in failed or nu in seen :
            continue 
        seen .add (nu )
        tasks .append (rec )
LIMIT =int (os .environ .get ("CRAWL_LIMIT","0")or 0 )
if LIMIT :
    tasks =tasks [:LIMIT ]
print (f"tasks to crawl: {len (tasks )}")

lock =threading .Lock ()
stats ={"ok":0 ,"fail":0 ,"start":time .time (),"processed":0 }

out_f =open (OUT_JSONL ,"a",encoding ="utf-8")
fail_f =open (FAIL_CSV ,"a",encoding ="utf-8-sig",newline ="")
fail_w =csv .writer (fail_f )

def worker (rec ):
    url =rec .get ("link","").strip ()
    html ,err =fetch (url )
    if html is None :
        return ("fail",rec ,err )
    content =extract (html )
    if not content or len (content )<30 :
        return ("fail",rec ,"no content extracted")
    return ("ok",rec ,content )

def report ():
    el =time .time ()-stats ["start"]
    rate =stats ["processed"]/el if el >0 else 0 
    with lock :
        p =stats ["processed"]
    rem =len (tasks )-p 
    eta =rem /rate if rate >0 else 0 
    line =(f"[{time .strftime ('%H:%M:%S')}] processed={p }/{len (tasks )} "
    f"ok={stats ['ok']} fail={stats ['fail']} rate={rate :.2f}/s ETA={eta /60 :.1f}min")
    print (line ,flush =True )
    with open (PROGRESS ,"w",encoding ="utf-8")as pf :
        pf .write (line +"\n")

try :
    with ThreadPoolExecutor (max_workers =MAX_WORKERS )as ex :
        futs ={ex .submit (worker ,rec ):rec for rec in tasks }
        for fut in as_completed (futs ):
            rec =futs [fut ]
            try :
                status ,r ,payload =fut .result ()
            except Exception as e :
                status ,r ,payload ="fail",rec ,f"worker-exc: {e }"
            with lock :
                stats ["processed"]+=1 
                if status =="ok":
                    rec_out ={
                    "date":r .get ("date",""),
                    "title":r .get ("title",""),
                    "source":r .get ("source",""),
                    "link":r .get ("link",""),
                    "content":payload ,
                    }
                    out_f .write (json .dumps (rec_out ,ensure_ascii =False )+"\n")
                    out_f .flush ()
                    stats ["ok"]+=1 
                else :
                    fail_w .writerow ([r .get ("link",""),payload ])
                    fail_f .flush ()
                    stats ["fail"]+=1 
            if stats ["processed"]%500 ==0 :
                report ()
    report ()
finally :
    out_f .close ()
    fail_f .close ()

print (f"DONE. ok={stats ['ok']} fail={stats ['fail']} total={len (tasks )}")
