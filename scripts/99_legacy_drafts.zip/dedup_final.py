# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

import json, re, os, csv
from collections import Counter

ROOT = r"D:\study\date\news\111zuixin\合并汇总"
SRC = os.path.join(ROOT, "有内容新闻_合并去重.jsonl")
OUT = os.path.join(ROOT, "有内容新闻_最终去重.jsonl")
MON = os.path.join(ROOT, "月度统计表_有内容_最终.csv")

def norm(s):
    s = (s or "").lower()
    s = re.sub(r"\s+", "", s)
    s = re.sub(r"[^\w\u4e00-\u9fff]", "", s)
    return s

seen = set()
title_seen = set()
monthly = Counter()
kept = 0
removed = 0

with open(SRC, encoding="utf-8") as fin, open(OUT, "w", encoding="utf-8") as fout:
    for line in fin:
        line = line.rstrip("\n")
        if not line.strip():
            continue
        r = json.loads(line)
        t = norm(r.get("title", ""))
        c = norm(r.get("content", ""))[:150]
        key = (t, c)
        if key in seen:
            removed += 1
            continue
        seen.add(key)
        title_seen.add(t)
        fout.write(line + "\n")
        ym = r.get("year_month") or (r.get("date", "")[:7])
        if ym:
            monthly[ym] += 1
        kept += 1

months = sorted(monthly)
with open(MON, "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["年月", "数量"])
    for m in months:
        w.writerow([m, monthly[m]])
    w.writerow(["合计", sum(monthly.values())])

print(f"Total amount of original deduplicated files read (kept+removed): {kept + removed}")
print(f"Final retention (after deduplication): {kept}")
print(f"Number of duplicates further removed in this round: {removed}")
print(f"Number of different titles after normalization: {len(title_seen)}")
print(f"Number of months covered by month: {len(months)}")
print(f"Peak month: {max(monthly, key=lambda k: monthly[k])} = {max(monthly.values())}")
