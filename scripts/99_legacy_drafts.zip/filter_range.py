# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Filter the data in the 2021-07 ~ 2026-06 interval and regenerate the monthly statistical table.
Source: News with content_Merge summary_0802_Including failure_Supplementary date.jsonl"""
import json ,os ,csv 
from collections import Counter 

BASE =r"D:\study\date\news\111zuixin\合并汇总"
SRC =os .path .join (BASE ,"有内容新闻_合并汇总_0802_含失败_补日期.jsonl")
OUT =os .path .join (BASE ,"有内容新闻_合并汇总_0802_202107_202606.jsonl")
MONTH_CSV =os .path .join (BASE ,"月度统计表_0802_202107_202606.csv")

LO ="2021-07"
HI ="2026-06"

def in_range (ym ):
    return ym >=LO and ym <=HI 

    # Generate window month list (including all 60 months, missing data will be filled with 0)
months =[]
y ,m =2021 ,7 
while (y ,m )<=(2026 ,6 ):
    months .append (f"{y :04d}-{m :02d}")
    m +=1 
    if m >12 :
        m =1 ;y +=1 

month ={m :Counter ()for m in months }# m -> {1: has content, 0: failed}
kept =0 ;excluded =0 ;total_in =0 
no_date_excluded =0 
with open (SRC ,encoding ="utf-8")as f ,open (OUT ,"w",encoding ="utf-8")as out :
    for line in f :
        r =json .loads (line );total_in +=1 
        ym =r .get ("year_month","")
        if not ym :
            no_date_excluded +=1 
            excluded +=1 
            continue 
        if not in_range (ym ):
            excluded +=1 
            continue 
        has =1 if (r .get ("has_content","True")=="True"or r .get ("content","").strip ())else 0 
        month [ym ][has ]+=1 
        out .write (json .dumps (r ,ensure_ascii =False )+"\n")
        kept +=1 

rows =[]
tot_c =tot_f =0 
for m in months :
    c ,fl =month [m ][1 ],month [m ][0 ]
    rows .append ([m ,c ,fl ,c +fl ]);tot_c +=c ;tot_f +=fl 
rows .append (["合计",tot_c ,tot_f ,tot_c +tot_f ])

with open (MONTH_CSV ,"w",encoding ="utf-8-sig",newline ="")as f :
    w =csv .writer (f )
    w .writerow (["月份","有内容条数","失败条数","合计条数"])
    w .writerows (rows )

print (f"Total source records: {total_in }")
print (f"Outside range/no date exclusion: {excluded } (no date {no_date_excluded })")
print (f"Interval retention: {kept } -> Content {tot_c } + Failure {tot_f } = {tot_c +tot_f }")
print (f"Number of window months: {len (months )} (2021-07 ~ 2026-06)")
