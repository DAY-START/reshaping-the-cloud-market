# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Filter the news in the specified time period in "Flush Crawler Summary.csv" and output it to "Flush Supplement.csv".

Filter range:
  - April 2023
  - May 2023
  - June 2023
  - All year 2024
  - Full year 2025
  - Full year 2026

Source file column: news date, news title, news source, original text link
Date format example: 2021-07-31 09:16:01"""

import csv 
import os 

# Path configuration (if you need to modify it, just change it here)
SRC_DIR =r"D:\study\date\news\tonghuashunpachong"
SRC_FILE ="同花顺爬虫汇总.csv"
OUT_FILE ="同花顺补充.csv"

src_path =os .path .join (SRC_DIR ,SRC_FILE )
out_path =os .path .join (SRC_DIR ,OUT_FILE )

# Target time period: (year, month) list; if month is None, it means the whole year
TARGET_RANGES =[
(2023 ,4 ),(2023 ,5 ),(2023 ,6 ),
(2024 ,None ),(2025 ,None ),(2026 ,None ),
]


def in_target (year ,month ):
    for y ,m in TARGET_RANGES :
        if year ==y and (m is None or month ==m ):
            return True 
    return False 


def main ():
    if not os .path .exists (src_path ):
        raise FileNotFoundError (f"Source file not found: {src_path }")

    total =0 
    matched =0 
    # Use utf-8-sig to remove BOM; keep header row
    with open (src_path ,"r",encoding ="utf-8-sig",newline ="")as fin ,open (out_path ,"w",encoding ="utf-8-sig",newline ="")as fout :
        reader =csv .reader (fin )
        writer =csv .writer (fout )

        header =next (reader )
        writer .writerow (header )

        for row in reader :
            total +=1 
            if not row :
                continue 
            date_str =row [0 ].strip ()
            # Parse "YYYY-MM-DD HH:MM:SS"
            try :
                y_str ,m_str ,_ =date_str .split ("-",2 )
                year =int (y_str )
                month =int (m_str )
            except (ValueError ,IndexError ):
            # Date format is abnormal, skip this line
                continue 

            if in_target (year ,month ):
                writer .writerow (row )
                matched +=1 

    print (f"Source file: {src_path }")
    print (f"Output file: {out_path }")
    print (f"Total number of lines (excluding headers): {total }")
    print (f"Number of rows that hit the filter: {matched }")


if __name__ =="__main__":
    main ()
