# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""The closing script after the crawling is completed:
Based on [the latest complete data merged summary\news with content_final deduplication.jsonl],
Superimpose the crawling results of batch 1 (flush supplement) + batch 2 (aggregate remaining),
Add the text to the original record with "only url and no text".
Regenerate: final jsonl with crawling text + monthly statistics table (with content) + uncompleted report.

Note: This script relies on the crawling product B1/B2 to be completely generated and should be run after the full crawling (task 8MSNN4) is completed."""
import csv ,json ,re ,os 
from collections import Counter 

BASE =r"D:\study\date\news"
B1 =os .path .join (BASE ,"tonghuashunpachong","crawl_batch1.jsonl")
B2 =os .path .join (BASE ,"tonghuashunpachong","crawl_batch2.jsonl")
OLD =os .path .join (BASE ,"111zuixin","合并汇总","有内容新闻_最终去重.jsonl")
OUTDIR =os .path .join (BASE ,"111zuixin","合并汇总")
OUT_JSONL =os .path .join (OUTDIR ,"有内容新闻_最终去重_补爬.jsonl")
OUT_CSV =os .path .join (OUTDIR ,"月度统计表_有内容_补爬后.csv")
OUT_MISS =os .path .join (OUTDIR ,"仍未补全_无正文记录.csv")

def norm_url (u ):
    u =(u or "").strip ()
    u =re .sub (r"[#?].*$","",u )
    u =re .sub (r"/$","",u )
    return u .lower ()

def ym_of (s ):
    if not s :return None 
    m =re .match (r"(\d{4}-\d{2})",str (s ).strip ())
    return m .group (1 )if m else None 

    # 1) Collect the successfully crawled text of B1+B2
crawled ={}
for path in (B1 ,B2 ):
    if not os .path .exists (path ):
        continue 
    with open (path ,encoding ="utf-8")as f :
        for line in f :
            try :r =json .loads (line )
            except :continue 
            c =(r .get ("content","")or "").strip ()
            if len (c )>=15 :
                crawled [norm_url (r .get ("url",""))]=c 
print (f"The number of URLs that can be used to complete the crawl results (text>=15 words): {len (crawled )}")

# 2) Read the base, supplement the text, and stream the final file + statistics
ok =filled =still_empty =0 
mm_counter =Counter ()
miss_by_month =Counter ()
with open (OLD ,encoding ="utf-8")as f ,open (OUT_JSONL ,"w",encoding ="utf-8")as fo ,open (OUT_MISS ,"w",encoding ="utf-8-sig",newline ="")as fm :
    fmw =csv .writer (fm )
    fmw .writerow (["新闻日期","新闻标题","新闻来源","原文链接","dataset"])
    for line in f :
        r =json .loads (line )
        c =(r .get ("content","")or "").strip ()
        if len (c )<15 :
            nu =norm_url (r .get ("url",""))
            if nu in crawled :
                r ["content"]=crawled [nu ]
                c =crawled [nu ]
                filled +=1 
        if len (c )>=15 :
            mm =ym_of (r .get ("date",""))
            if mm :mm_counter [mm ]+=1 
            ok +=1 
        else :
            still_empty +=1 
            mm =ym_of (r .get ("date",""))
            if mm :miss_by_month [mm ]+=1 
            if len (miss_by_month )<=100000 :# Control file size
                fmw .writerow ([r .get ("date",""),r .get ("title",""),r .get ("source",""),r .get ("url",""),r .get ("dataset","")])
        fo .write (json .dumps (r ,ensure_ascii =False )+"\n")

print (f"Finally, there are news items with content: {ok } items (this crawling has completed {filled } items, but there is still no text {still_empty } items)")

# 3) Write monthly statistics table (with content)
months =sorted (mm_counter )
with open (OUT_CSV ,"w",encoding ="utf-8-sig",newline ="")as fo :
    w =csv .writer (fo )
    w .writerow (["年月","有内容新闻条数"])
    for m in months :
        w .writerow ([m ,mm_counter [m ]])
    w .writerow (["合计",sum (mm_counter .values ())])

print (f"The monthly statistical table has been written: {OUT_CSV } (covering {len (months )} month)")
print ("Unfinished (still no text) distribution by month:")
for m in sorted (miss_by_month ):
    print (f"  {m }: {miss_by_month [m ]}")
print ("DONE")
