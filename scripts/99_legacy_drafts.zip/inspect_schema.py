# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

import json, os

base = r"D:\study\date\news\111zuixin"
files = [
 "workbuddy/workbuddyai_compute_news_2023_2026.jsonl",
 "yuanbao/yuanbaoai_computing_power_news.jsonl",
 "gpt_verified/gptverified_seed_zh.jsonl",
 "crawler/AI_Computing_News_Crawler_20230401_20260630.jsonl",
 "historical_web/AI_Computing_Historical_Web_News_20210701_20260630.jsonl",
 "ths/AI_Computing_News_THS_Fulltext_Deduplicated.jsonl",
 "ths/daily_2026-07-30.jsonl",
 "kimi/kimiAI算力新闻数据集_2023-2026.json",
 "doubao/doubao算力财经新闻数据集（2026年6-7月，3033条）.jsonl",
 "datelab_raw/AI_Computing_News_Raw_after_20210701.jsonl",
 "unified/AI_Computing_News_Unified_20210701_20260630.jsonl",
]
for f in files:
    p = os.path.join(base, f)
    try:
        if f.endswith(".json"):
            with open(p, encoding="utf-8") as fh:
                data = json.load(fh)
            print(f"\n### {f}  [JSON array, len={len(data)}]")
            rec = data[0] if data else {}
        else:
            with open(p, encoding="utf-8") as fh:
                line = fh.readline()
            rec = json.loads(line)
            print(f"\n### {f}  [JSONL, first record]")
        print("  keys:", list(rec.keys()))
        for k, v in rec.items():
            s = str(v)
            if len(s) > 70:
                s = s[:70] + "..."
            print(f"    {k}: {s}")
    except Exception as e:
        print(f"\n### {f}  ERROR: {e}")
