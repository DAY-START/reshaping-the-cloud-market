# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Merge the previous largest file (359930) and the current computer equipment (27654) data set, deduplicate across files, and save note 0802.
Key to deduplication: (standardized title, first 150 words of text) - consistent with the previous final deduplication criteria.
The old data set will be retained first (including dataset/reason traceability information), and the new data will only supplement the non-duplicate parts."""
import os ,json ,re ,csv 
from collections import Counter 

PREV =r"D:\study\date\news\111zuixin\合并汇总\有内容新闻_最终去重_补爬.jsonl"
NEW =r"D:\study\date\同花顺新闻\合并汇总\计算机设备_最终去重.jsonl"
OUT_DIR =r"D:\study\date\news\111zuixin\合并汇总"
os .makedirs (OUT_DIR ,exist_ok =True )
OUT_JSONL =os .path .join (OUT_DIR ,"有内容新闻_合并汇总_0802.jsonl")
MONTH_CSV =os .path .join (OUT_DIR ,"月度统计表_合并汇总_0802.csv")

def norm_title (t ):
    return re .sub (r"\s+","",str (t )).lower ()if t else ""

def key_of (rec ):
    t =norm_title (rec .get ("title",""))
    c =rec .get ("content","")or ""
    return t +"\u0001"+c [:150 ]

seen =set ()
out =[]
stats ={"prev_total":0 ,"new_total":0 ,"prev_kept":0 ,"new_added":0 ,"new_dup":0 }

def emit (rec ):
    ym =rec .get ("year_month")or (rec .get ("date","")or "")[:7 ]
    url =rec .get ("url")or rec .get ("link")or ""
    ds =rec .get ("dataset")or "unknown"
    out .append ({
    "date":rec .get ("date",""),
    "year_month":ym ,
    "title":rec .get ("title",""),
    "source":rec .get ("source",""),
    "url":url ,
    "content":rec .get ("content","")or "",
    "dataset":ds ,
    })

    # 1) Old data set (preferred to be retained)
with open (PREV ,"r",encoding ="utf-8")as f :
    for line in f :
        line =line .strip ()
        if not line :
            continue 
        try :
            rec =json .loads (line )
        except Exception :
            continue 
        stats ["prev_total"]+=1 
        k =key_of (rec )
        if k in seen :
            continue 
        seen .add (k )
        emit (rec )
        stats ["prev_kept"]+=1 

        # 2) New data set (only supplementary and not repeated)
with open (NEW ,"r",encoding ="utf-8")as f :
    for line in f :
        line =line .strip ()
        if not line :
            continue 
        try :
            rec =json .loads (line )
        except Exception :
            continue 
        stats ["new_total"]+=1 
        k =key_of (rec )
        if k in seen :
            stats ["new_dup"]+=1 
            continue 
        seen .add (k )
        rec ["dataset"]="Computer equipment source files"
        emit (rec )
        stats ["new_added"]+=1 

        # write result
with open (OUT_JSONL ,"w",encoding ="utf-8")as f :
    for rec in out :
        f .write (json .dumps (rec ,ensure_ascii =False )+"\n")

        # monthly statistics
mc =Counter (r ["year_month"]for r in out if r ["year_month"])
months =sorted (mc .keys ())
with open (MONTH_CSV ,"w",encoding ="utf-8-sig",newline ="")as f :
    w =csv .writer (f )
    w .writerow (["月份","新闻条数"])
    for m in months :
        w .writerow ([m ,mc [m ]])
    w .writerow (["合计",sum (mc .values ())])

    # Source (dataset) statistics
dc =Counter (r ["dataset"]for r in out )
print ("=== Merged results (remark 0802) ===")
print ("Total old data set size:",stats ["prev_total"],"reserve:",stats ["prev_kept"])
print ("Total new data set size:",stats ["new_total"],"New:",stats ["new_added"],"Skip with old duplicates:",stats ["new_dup"])
print ("Combined total:",len (out ))
print ("Number of months:",len (months ),"span:",months [0 ],"~",months [-1 ])
print ("Data set distribution:",dc .most_common (10 ))
print ("OUTPUT:",OUT_JSONL )
print ("OUTPUT:",MONTH_CSV )
