# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Merge all news data sets under D:/study/date/news/111zuixin.
Classification rules (strict, not fabricated):
  Group A (valid news) = can parse out the complete date (YYYY-MM-DD) and has real news text (>=15 words and no placeholder)
  Group B (no text/no date) = the rest, only full statistics will be done, and will not be entered into the main file for merging and deduplication.
Removal of duplicates: Group A presses (normalized title, date) to remove duplicates, leaving only one item; Group B also presses (title, date) to remove duplicates.
Duplicate copies: If a key is already in seen (indicating that a previous file has been included and is a copy), it will be included in dup and will not be counted repeatedly.
Exclude: summary/subdirectory (last round of products), *_TEST* files, empty files, collection list.csv.
All files are read uniformly using utf-8-sig (compatible with/without BOM)."""
import os ,re ,json ,csv 
from datetime import datetime 

ROOT =r"D:\study\date\news\111zuixin"
BASE =r"D:\study\date\news"
OUT =os .path .join (ROOT ,"合并汇总")
os .makedirs (OUT ,exist_ok =True )
SCAN_ROOTS =[ROOT ,r"D:\study\date\news\data"]# Additional inclusion in the data directory (all user requirements are included)

EXCLUDE_DIRS ={"汇总","合并汇总"}
SKIP_SUBSTR =["_TEST","TEST_"]

PLACEHOLDERS =["点击查看原文","查看原文","点击查看","阅读原文","详情点击",
"点击阅读全文","查看更多","点此查看","点击进入","查看详情"]

def get (rec ,*keys ,default =""):
    for k in keys :
        if k in rec and rec [k ]not in (None ,""):
            return str (rec [k ])
    return default 

def extract (rec ):
    title =get (rec ,"title","headline","name","新闻标题","name")
    date_raw =get (rec ,"date","time","publish_time","pub_time","news_date",
    "Release time","新闻日期","datetime","release date","crawl_time","display_time")
    content =get (rec ,"content","text","summary","text","body","desc","content","article")
    source =get (rec ,"source","来源","news_source","media","publish_source","host_source")
    url =get (rec ,"url","link","原文链接","href","News link")
    return title .strip (),date_raw .strip (),content .strip (),source .strip (),url .strip ()

def parse_date (raw ):
    if not raw :
        return None 
    s =raw .strip ()
    if re .fullmatch (r"\d{13}",s ):
        try :return datetime .fromtimestamp (int (s )/1000 )
        except :pass 
    if re .fullmatch (r"\d{10}",s ):
        try :return datetime .fromtimestamp (int (s ))
        except :pass 
    m =re .search (r"(\d{4})[-/年.](\d{1,2})[-/月.](\d{1,2})",s )
    if m :
        try :return datetime (int (m .group (1 )),int (m .group (2 )),int (m .group (3 )))
        except :return None 
    return None 

def has_content (c ):
    if len (c )<15 :
        return False 
    bare =re .sub (r"[\s\W_]+","",c )
    for ph in PLACEHOLDERS :
        if ph in bare and len (bare )<=len (ph )+12 :
            return False 
    return True 

def norm_key (title ,ymd ):
    t =re .sub (r"\s+","",title ).lower ()
    if not t :
        t ="#nocontent#"
    return f"{t }||{ymd }"

    # Collect files (multiple roots: 111zuixin + data)
data_files =[]
for ROOT0 in SCAN_ROOTS :
    for dp ,dns ,fns in os .walk (ROOT0 ):
        dns [:]=[d for d in dns if d not in EXCLUDE_DIRS ]
        for fn in fns :
            if any (p in fn for p in SKIP_SUBSTR ):
                continue 
            if fn in ("归集清单.csv",):
                continue 
            if fn .lower ().endswith ((".jsonl",".json",".csv")):
                full =os .path .join (dp ,fn )
                try :
                    if os .path .getsize (full )==0 :
                        print (f"[Skip] Empty file: {full }")
                        continue 
                except OSError :
                    continue 
                data_files .append (full )

print (f"Found {len (data_files )} data files, started processing...\n")

fa =open (os .path .join (OUT ,"有内容新闻_合并去重.jsonl"),"w",encoding ="utf-8")
fb =open (os .path .join (OUT ,"无正文内容_统计.jsonl"),"w",encoding ="utf-8")

seen_a ,seen_b =set (),set ()
month_a ,month_b ={},{}
src_stat ={}
b_reason ={"无正文内容":0 ,"日期无法解析":0 ,"既无正文也无日期":0 }

def rel (p ):return os .path .relpath (p ,BASE )

def write_rec (fh ,title ,date_iso ,ym ,content ,source ,url ,dataset ,reason ):
    fh .write (json .dumps ({
    "date":date_iso ,"year_month":ym ,"title":title ,
    "source":source ,"url":url ,"content":content ,
    "dataset":dataset ,"reason":reason ,
    },ensure_ascii =False )+"\n")

for fp in data_files :
    name =rel (fp )
    stat ={"total":0 ,"a":0 ,"b":0 ,"dup_a":0 ,"dup_b":0 ,"has_cf":None ,"note":"ok"}
    ext =fp .lower ()
    try :
        if ext .endswith (".csv"):
            with open (fp ,encoding ="utf-8-sig",errors ="replace")as fh :
                reader =csv .DictReader (fh )
                for row in reader :
                    stat ["total"]+=1 
                    title ,date_raw ,content ,source ,url =extract (row )
                    if stat ["has_cf"]is None :
                        stat ["has_cf"]=(content !="")
                    dt =parse_date (date_raw )
                    diso =dt .strftime ("%Y-%m-%d")if dt else ""
                    ym =f"{dt .year :04d}-{dt .month :02d}"if dt else None 
                    if dt and has_content (content ):
                        key =norm_key (title ,diso )
                        if key not in seen_a :
                            seen_a .add (key );stat ["a"]+=1 ;month_a [ym ]=month_a .get (ym ,0 )+1 
                            write_rec (fa ,title ,diso ,ym ,content ,source ,url ,name ,"")
                        else :
                            stat ["dup_a"]+=1 
                    else :
                        key =norm_key (title ,diso or "NODATE")
                        if key not in seen_b :
                            seen_b .add (key );stat ["b"]+=1 
                            reason ="既无正文也无日期"if (not dt and not has_content (content ))else ("日期无法解析"if not dt else "无正文内容")
                            b_reason [reason ]=b_reason .get (reason ,0 )+1 
                            write_rec (fb ,title ,diso ,ym or "unknown",content ,source ,url ,name ,reason )
                            if ym :month_b [ym ]=month_b .get (ym ,0 )+1 
                            else :month_b ["未知日期"]=month_b .get ("未知日期",0 )+1 
                        else :
                            stat ["dup_b"]+=1 
        else :
            with open (fp ,encoding ="utf-8-sig",errors ="replace")as fh :
                if ext .endswith (".json"):
                    data =json .load (fh )
                    items =data if isinstance (data ,list )else [data ]
                else :
                    items =(json .loads (line )for line in fh if line .strip ())
                for rec in items :
                    if not isinstance (rec ,dict ):
                        continue 
                    stat ["total"]+=1 
                    title ,date_raw ,content ,source ,url =extract (rec )
                    if stat ["has_cf"]is None :
                        stat ["has_cf"]=(content !="")
                    dt =parse_date (date_raw )
                    diso =dt .strftime ("%Y-%m-%d")if dt else ""
                    ym =f"{dt .year :04d}-{dt .month :02d}"if dt else None 
                    if dt and has_content (content ):
                        key =norm_key (title ,diso )
                        if key not in seen_a :
                            seen_a .add (key );stat ["a"]+=1 ;month_a [ym ]=month_a .get (ym ,0 )+1 
                            write_rec (fa ,title ,diso ,ym ,content ,source ,url ,name ,"")
                        else :
                            stat ["dup_a"]+=1 
                    else :
                        key =norm_key (title ,diso or "NODATE")
                        if key not in seen_b :
                            seen_b .add (key );stat ["b"]+=1 
                            reason ="既无正文也无日期"if (not dt and not has_content (content ))else ("日期无法解析"if not dt else "无正文内容")
                            b_reason [reason ]=b_reason .get (reason ,0 )+1 
                            write_rec (fb ,title ,diso ,ym or "unknown",content ,source ,url ,name ,reason )
                            if ym :month_b [ym ]=month_b .get (ym ,0 )+1 
                            else :month_b ["未知日期"]=month_b .get ("未知日期",0 )+1 
                        else :
                            stat ["dup_b"]+=1 
    except Exception as e :
        stat ["note"]=f"ERROR: {e }"
        print (f"[Error] {name }: {e }")
    src_stat [name ]=stat 
    print (f"{name :52s} Total={stat ['total']:>7d} A Valid={stat ['a']:>7d} B No text={stat ['b']:>7d} Repeat skip={stat ['dup_a']+stat ['dup_b']:>7d}")

fa .close ();fb .close ()

# Monthly Schedule A
months =sorted (month_a .keys ())
with open (os .path .join (OUT ,"月度统计表_有内容.csv"),"w",encoding ="utf-8-sig",newline ="")as fh :
    w =csv .writer (fh );w .writerow (["年月","有内容新闻条数"])
    for m in months :w .writerow ([m ,month_a [m ]])
    w .writerow (["合计",sum (month_a .values ())])

    # Monthly Schedule B
months_b =sorted ([k for k in month_b if k !="未知日期"])
with open (os .path .join (OUT ,"月度统计表_无正文内容.csv"),"w",encoding ="utf-8-sig",newline ="")as fh :
    w =csv .writer (fh );w .writerow (["年月","无正文/无日期条数"])
    for m in months_b :w .writerow ([m ,month_b [m ]])
    if "未知日期"in month_b :w .writerow (["未知日期",month_b ["未知日期"]])
    w .writerow (["合计",sum (month_b .values ())])

    # Source statistics
with open (os .path .join (OUT ,"数据集来源统计.csv"),"w",encoding ="utf-8-sig",newline ="")as fh :
    w =csv .writer (fh );w .writerow (["数据集(相对路径)","记录总数","A有效","B无正文","重复跳过","含正文列","备注"])
    for n ,s in src_stat .items ():
        w .writerow ([n ,s ["total"],s ["a"],s ["b"],s ["dup_a"]+s ["dup_b"],
        ("yes"if s ["has_cf"]else "no"),s ["note"]])

        # illustrate
with open (os .path .join (OUT ,"处理说明.txt"),"w",encoding ="utf-8")as fh :
    fh .write ("合并汇总处理说明\n"+"="*50 +"\n\n")
    fh .write ("输入目录: D:\\study\\date\\news\\111zuixin (不含 汇总/ 子目录)\n")
    fh .write ("排除: *_TEST* 文件、空文件、归集清单.csv\n")
    fh .write ("读取编码: utf-8-sig (兼容带/不带 BOM)\n\n")
    fh .write ("【A组 有效新闻】= 能解析完整日期(YYYY-MM-DD) 且 有真实新闻正文(>=15字且非占位)\n")
    fh .write ("【B组 无正文/无日期】= 其余全部，仅全量统计，不去重合并进主文件\n")
    fh .write ("【重复跳过】= 与前面已处理文件 content key 重复(副本)，不重复计数\n\n")
    fh .write (f"Group A (contains content, removes duplicates): {sum (month_a .values ())} items \n")
    fh .write (f"Group B (no text/no date): {sum (month_b .values ())} items \n")
    fh .write (f"No text content: {b_reason .get ('无正文内容',0 )}\n")
    fh .write (f"Unable to parse date: {b_reason .get ('日期无法解析',0 )}\n")
    fh .write (f"No text or date: {b_reason .get ('既无正文也无日期',0 )}\n")
    fh .write (f"Unknown date: {month_b .get ('未知日期',0 )}\n")
    fh .write ("\n去重键: (规范化标题, 日期)。未臆造任何数据，缺失即归B组统计。\n")

print ("\n===== 完成 =====")
print (f"Group A contains news (remove duplicates): {sum (month_a .values ())} items, covering {len (months )} month")
print (f"Group B No text/no date (full quantity): {sum (month_b .values ())} Articles")
print (f"- No text content: {b_reason .get ('无正文内容',0 )}")
print (f"- Date cannot be parsed: {b_reason .get ('日期无法解析',0 )}")
print (f"- Neither text nor date: {b_reason .get ('既无正文也无日期',0 )}")
print (f"Output directory: {OUT }")
