# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Merge the records of successful re-crawling back into the 0802 data set (breakpoint safety: write the temporary file first and then replace it).
Cross-file deduplication key: (normalized title, first 150 words of text)."""
import os ,json ,re ,csv 
from collections import Counter 

OUT_DIR =r"D:\study\date\news\111zuixin\合并汇总"
BASE =os .path .join (OUT_DIR ,"有内容新闻_合并汇总_0802.jsonl")
RECOVERED =os .path .join (OUT_DIR ,"失败重试_带内容.jsonl")
MONTH_CSV =os .path .join (OUT_DIR ,"月度统计表_合并汇总_0802.csv")
TMP =os .path .join (OUT_DIR ,"有内容新闻_合并汇总_0802.tmp.jsonl")

DS_MAP ={
"计算机设备":"Computer equipment source files",
"daily_2026-07-30":"daily_2026-07-30_failures",
"fulltext":"fulltext_failures",
}

def norm_title (t ):
    return re .sub (r"\s+","",str (t )).lower ()if t else ""

def key_of (rec ):
    return norm_title (rec .get ("title",""))+"\u0001"+(rec .get ("content","")or "")[:150 ]

def emit (rec ):
    ym =rec .get ("year_month")or (rec .get ("date","")or "")[:7 ]
    return {
    "date":rec .get ("date",""),
    "year_month":ym ,
    "title":rec .get ("title",""),
    "source":rec .get ("source",""),
    "url":rec .get ("url")or rec .get ("link")or "",
    "content":rec .get ("content","")or "",
    "dataset":rec .get ("dataset",""),
    }

seen =set ()
out =[]
base_n =rec_n =added =0 

# 1) Basic set (priority, traceability retained)
with open (BASE ,"r",encoding ="utf-8")as f :
    for line in f :
        if not line .strip ():continue 
        try :rec =json .loads (line )
        except :continue 
        base_n +=1 
        k =key_of (rec )
        if k in seen :continue 
        seen .add (k )
        out .append (emit (rec ))

        # 2) Re-climb the successful set
with open (RECOVERED ,"r",encoding ="utf-8")as f :
    for line in f :
        if not line .strip ():continue 
        try :rec =json .loads (line )
        except :continue 
        rec_n +=1 
        k =key_of (rec )
        if k in seen :# Duplicate with base set (rarely)
            continue 
        seen .add (k )
        ds =DS_MAP .get (rec .get ("origin",""),"Retry completion on failure")
        rec ["dataset"]=ds 
        out .append (emit (rec ))
        added +=1 

with open (TMP ,"w",encoding ="utf-8")as f :
    for r in out :
        f .write (json .dumps (r ,ensure_ascii =False )+"\n")
os .replace (TMP ,BASE )

mc =Counter (r ["year_month"]for r in out if r ["year_month"])
months =sorted (mc .keys ())
with open (MONTH_CSV ,"w",encoding ="utf-8-sig",newline ="")as f :
    w =csv .writer (f )
    w .writerow (["月份","新闻条数"])
    for m in months :
        w .writerow ([m ,mc [m ]])
    w .writerow (["合计",sum (mc .values ())])

dc =Counter (r ["dataset"]for r in out )
print ("=== Merge re-crawling results to 0802 ===")
print ("Basic set:",base_n ,"Re-climbing successfully:",rec_n ,"Newly added to the database:",added )
print ("Combined total:",len (out ))
print ("Data set distribution Top:",dc .most_common (6 ))
print ("OUTPUT:",BASE )
print ("OUTPUT:",MONTH_CSV )
