# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Merge the successful records of the improved version of re-crawling (failure retry 2) back into the 0802 data set."""
import os ,json ,re ,csv 
from collections import Counter 

OUT_DIR =r"D:\study\date\news\111zuixin\合并汇总"
BASE =os .path .join (OUT_DIR ,"有内容新闻_合并汇总_0802.jsonl")
RECOVERED =os .path .join (OUT_DIR ,"失败重试2_带内容.jsonl")
MONTH_CSV =os .path .join (OUT_DIR ,"月度统计表_合并汇总_0802.csv")
TMP =os .path .join (OUT_DIR ,"有内容新闻_合并汇总_0802.tmp.jsonl")

def norm_title (t ):
    return re .sub (r"\s+","",str (t )).lower ()if t else ""

def key_of (rec ):
    return norm_title (rec .get ("title",""))+"\u0001"+(rec .get ("content","")or "")[:150 ]

def emit (rec ):
    ym =rec .get ("year_month")or (rec .get ("date","")or "")[:7 ]
    return {
    "date":rec .get ("date",""),
    "year_month":ym ,
    "title":rec .get ("title",""),
    "source":rec .get ("source",""),
    "url":rec .get ("url")or rec .get ("link")or "",
    "content":rec .get ("content","")or "",
    "dataset":rec .get ("dataset",""),
    }

seen =set ()
out =[]
base_n =rec_n =added =0 

with open (BASE ,"r",encoding ="utf-8")as f :
    for line in f :
        if not line .strip ():
            continue 
        try :
            rec =json .loads (line )
        except Exception :
            continue 
        base_n +=1 
        k =key_of (rec )
        if k in seen :
            continue 
        seen .add (k )
        out .append (emit (rec ))

with open (RECOVERED ,"r",encoding ="utf-8")as f :
    for line in f :
        if not line .strip ():
            continue 
        try :
            rec =json .loads (line )
        except Exception :
            continue 
        rec_n +=1 
        k =key_of (rec )
        if k in seen :
            continue 
        seen .add (k )
        out .append (emit (rec ))
        added +=1 

with open (TMP ,"w",encoding ="utf-8")as f :
    for r in out :
        f .write (json .dumps (r ,ensure_ascii =False )+"\n")
os .replace (TMP ,BASE )

mc =Counter (r ["year_month"]for r in out if r ["year_month"])
months =sorted (mc .keys ())
with open (MONTH_CSV ,"w",encoding ="utf-8-sig",newline ="")as f :
    w =csv .writer (f )
    w .writerow (["月份","新闻条数"])
    for m in months :
        w .writerow ([m ,mc [m ]])
    w .writerow (["合计",sum (mc .values ())])

print ("=== Merge the improved version of re-crawling results to 0802 ===")
print ("Basic set:",base_n ,"Re-climbing successfully:",rec_n ,"Newly added to the database:",added )
print ("Combined total:",len (out ))
print ("OUTPUT:",BASE )
print ("OUTPUT:",MONTH_CSV )
