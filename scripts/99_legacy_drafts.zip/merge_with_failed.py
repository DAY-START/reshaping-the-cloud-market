# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Backfill the metadata of the links that just failed (including those that still fail after retrying) and merge them into the summary to generate a complete version + monthly table including failures.
Keep the original 0802 (with content) file unchanged and create a new *_including failure.* full version.
Failed link metadata source: Computer Equipment_Merge Deduplication.jsonl (date/title/source/link/_nu)."""
import os ,json ,csv ,re 
from collections import Counter ,defaultdict 

OUT_DIR =r"D:\study\date\news\111zuixin\合并汇总"
BASE =os .path .join (OUT_DIR ,"有内容新闻_合并汇总_0802.jsonl")
XLS_JSONL =r"D:\study\date\同花顺新闻\合并汇总\计算机设备_合并去重.jsonl"
FAIL_CSV =os .path .join (OUT_DIR ,"失败重试2_仍失败.csv")

COMB_JSONL =os .path .join (OUT_DIR ,"有内容新闻_合并汇总_0802_含失败.jsonl")
COMB_MONTH =os .path .join (OUT_DIR ,"月度统计表_合并汇总_0802_含失败.csv")
TMP =os .path .join (OUT_DIR ,"有内容新闻_合并汇总_0802_含失败.tmp.jsonl")

def nu (u ):
    u =(u or "").strip ()
    return re .split (r"[#?]",u )[0 ].rstrip ("/").lower ()

    # 1) Computer device source metadata map: _nu -> rec
meta ={}
for line in open (XLS_JSONL ,encoding ="utf-8"):
    line =line .strip ()
    if not line :
        continue 
    r =json .loads (line )
    k =r .get ("_nu")or nu (r .get ("link")or r .get ("url")or "")
    if k :
        meta [k ]=r 

        # 2) Failed to read csv -> record
failed =[]
with open (FAIL_CSV ,encoding ="utf-8-sig")as f :
    rd =csv .reader (f )
    header =next (rd ,None )
    for row in rd :
        if not row or not row [0 ].strip ():
            continue 
        failed .append ({"url":row [0 ].strip (),
        "reason":row [1 ]if len (row )>1 else "",
        "title":row [2 ]if len (row )>2 else "",
        "date":row [3 ]if len (row )>3 else "",
        "source":row [4 ]if len (row )>4 else "",
        "dataset":row [5 ]if len (row )>5 else ""})

        # 3) Complete assembly records
out =[]
ok_month =Counter ()# Content available monthly
fail_month =Counter ()# Failure by month
undated_fail =0 

# 3a) There is content (0802)
base_n =0 
for line in open (BASE ,encoding ="utf-8"):
    line =line .strip ()
    if not line :
        continue 
    r =json .loads (line )
    base_n +=1 
    ym =r .get ("year_month")or (r .get ("date")or "")[:7 ]
    if ym :
        ok_month [ym ]+=1 
    out .append ({
    "date":r .get ("date",""),
    "year_month":ym ,
    "title":r .get ("title",""),
    "source":r .get ("source",""),
    "url":r .get ("url")or r .get ("link")or "",
    "content":r .get ("content","")or "",
    "dataset":r .get ("dataset",""),
    "has_content":True ,
    })

    # 3b) Failure (backfill metadata)
rec_n =0 
matched =0 
for rec in failed :
    rec_n +=1 
    m =meta .get (nu (rec ["url"]))
    if m :
        matched +=1 
        date =m .get ("date","")or rec ["date"]
        title =m .get ("title","")or rec ["title"]
        source =m .get ("source","")or rec ["source"]
        ds =m .get ("dataset")or rec ["dataset"]or "Computer equipment source files"
    else :
        date =rec ["date"]
        title =rec ["title"]
        source =rec ["source"]
        ds =rec ["dataset"]or "Failure without source"
    ym =(date or "")[:7 ]
    if ym :
        fail_month [ym ]+=1 
    else :
        undated_fail +=1 
    out .append ({
    "date":date ,
    "year_month":ym ,
    "title":title ,
    "source":source ,
    "url":rec ["url"],
    "content":"",
    "dataset":ds ,
    "has_content":False ,
    "fail_reason":rec ["reason"],
    })

with open (TMP ,"w",encoding ="utf-8")as f :
    for r in out :
        f .write (json .dumps (r ,ensure_ascii =False )+"\n")
os .replace (TMP ,COMB_JSONL )

# 4) Monthly table (with content/failure/total)
months =sorted (set (ok_month )|set (fail_month ))
with open (COMB_MONTH ,"w",encoding ="utf-8-sig",newline ="")as f :
    w =csv .writer (f )
    w .writerow (["月份","有内容条数","失败条数","合计条数"])
    for m in months :
        o =ok_month .get (m ,0 )
        fa =fail_month .get (m ,0 )
        w .writerow ([m ,o ,fa ,o +fa ])
    if undated_fail :
        w .writerow (["无日期",0 ,undated_fail ,undated_fail ])
    w .writerow (["合计",sum (ok_month .values ()),sum (fail_month .values ())+undated_fail ,
    sum (ok_month .values ())+sum (fail_month .values ())+undated_fail ])

print ("=== Including failed merge summary ===")
print ("Contents (basic):",base_n ,"fail:",rec_n ,"The metadata is backfilled:",matched ,"No source:",rec_n -matched )
print ("Combined total:",len (out ))
print ("Monthly table: has content",sum (ok_month .values ()),"+ fail",sum (fail_month .values ()),
"+ no date",undated_fail ,"=",sum (ok_month .values ())+sum (fail_month .values ())+undated_fail )
print ("OUTPUT:",COMB_JSONL )
print ("OUTPUT:",COMB_MONTH )
