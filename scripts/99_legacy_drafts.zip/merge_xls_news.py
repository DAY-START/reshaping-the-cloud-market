# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Merge all .xls under D:/study/date/flush news/computer equipment source files and remove duplicates.
Each file: sheet 'Financial news export list', columns: news date, news title, news source, original text link
Only links, no text -> Merged and deduplicated for subsequent crawling."""
import xlrd ,os ,glob ,json ,re ,csv 

SRC =r"D:\study\date\同花顺新闻\计算机设备源文件"
OUT_DIR =r"D:\study\date\同花顺新闻\合并汇总"
os .makedirs (OUT_DIR ,exist_ok =True )

def norm_url (u ):
    if not u :
        return ""
    u =str (u ).strip ()
    u =re .split (r"[#?]",u )[0 ]# Go to # and trace parameters
    u =u .rstrip ("/")# Remove trailing slash
    u =u .lower ()
    return u 

def norm_title (t ):
    if not t :
        return ""
    return re .sub (r"\s+","",str (t )).lower ()

def norm_date (d ):
# Expect '2024-01-31 23:32:13' -> '2024-01-31'
    if d is None :
        return ""
    s =str (d ).strip ()
    m =re .match (r"(\d{4})[-/年](\d{1,2})[-/月](\d{1,2})",s )
    if m :
        return f"{int (m .group (1 )):04d}-{int (m .group (2 )):02d}-{int (m .group (3 )):02d}"
    return s [:10 ]

files =sorted (glob .glob (os .path .join (SRC ,"*.xls")))
print ("found files:",len (files ))

records =[]
empty_files =[]
for f in files :
    base =os .path .basename (f )
    try :
        if os .path .getsize (f )==0 :
            empty_files .append (base );continue 
        bk =xlrd .open_workbook (f )
        sh =bk .sheet_by_index (0 )
    except Exception as e :
        print ("SKIP",base ,e );continue 
        # Find column index (fault tolerance)
    hdr =[str (sh .cell_value (0 ,c )).strip ()for c in range (sh .ncols )]
    idx ={}
    for key in ["新闻日期","新闻标题","新闻来源","原文链接"]:
        if key in hdr :
            idx [key ]=hdr .index (key )
        else :
        # Sequential rollback
            idx ={k :i for i ,k in enumerate (["新闻日期","新闻标题","新闻来源","原文链接"])}
            break 
    cnt =0 
    for r in range (1 ,sh .nrows ):
        def val (col ):
            i =idx .get (col )
            return sh .cell_value (r ,i )if (i is not None and i <sh .ncols )else ""
        date_raw =val ("新闻日期")
        title =val ("新闻标题")
        source =val ("新闻来源")
        link =val ("原文链接")
        if not str (title ).strip ()and not str (link ).strip ():
            continue 
        cnt +=1 
        records .append ({
        "date":norm_date (date_raw ),
        "title":str (title ).strip (),
        "source":str (source ).strip (),
        "link":str (link ).strip (),
        })
    if cnt ==0 :
        empty_files .append (base )
    print (f"  {base }: {cnt } rows")

print ("total raw rows:",len (records ))
print ("empty/skipped files:",empty_files )

# Deduplication: First press the normalized link (if the url is empty, use title + date)
seen_url =set ()
seen_td =set ()
unique =[]
dup_url =0 
dup_td =0 
no_link =0 
for rec in records :
    nu =norm_url (rec ["link"])
    nt =norm_title (rec ["title"])
    nd =rec ["date"]
    if not nt and not nu :
        continue 
    if nu :
        if nu in seen_url :
            dup_url +=1 ;continue 
        seen_url .add (nu )
    else :
        no_link +=1 
    td =(nt ,nd )
    if td in seen_td :
    # Same title and same day but different links are still considered duplicate news
        dup_td +=1 
        continue 
    seen_td .add (td )
    rec ["_nu"]=nu 
    unique .append (rec )

print ("unique records:",len (unique ))
print ("  dup by url:",dup_url ," dup by (title,date):",dup_td ," no-link:",no_link )

# Output merge and deduplication (no text)
out_jsonl =os .path .join (OUT_DIR ,"计算机设备_合并去重.jsonl")
with open (out_jsonl ,"w",encoding ="utf-8")as f :
    for rec in unique :
        f .write (json .dumps (rec ,ensure_ascii =False )+"\n")

        # At the same time, output csv for easy viewing
out_csv =os .path .join (OUT_DIR ,"计算机设备_合并去重.csv")
with open (out_csv ,"w",encoding ="utf-8-sig",newline ="")as f :
    w =csv .writer (f )
    w .writerow (["新闻日期","新闻标题","新闻来源","原文链接"])
    for rec in unique :
        w .writerow ([rec ["date"],rec ["title"],rec ["source"],rec ["link"]])

        # Monthly distribution (based on date)
from collections import Counter 
mc =Counter (rec ["date"][:7 ]for rec in unique if rec ["date"])
print ("months covered:",len (mc ))
print ("top months:",mc .most_common (10 ))

# Count the number of crawling targets (with links and unique ones)
crawl_targets =sum (1 for rec in unique if rec ["_nu"])
print ("crawl targets (unique links):",crawl_targets )

print ("OUTPUT:",out_jsonl )
print ("OUTPUT:",out_csv )
