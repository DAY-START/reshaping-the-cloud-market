# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

import csv ,json ,os ,re 
from collections import Counter 

# Target month collection (user specifies the need for supplementary content)
TARGET_MONTHS =set ()
for m in (4 ,5 ,6 ):
    TARGET_MONTHS .add (f"2023-{m :02d}")
for y in (2024 ,2025 ,2026 ):
    for m in range (1 ,13 ):
        TARGET_MONTHS .add (f"{y }-{m :02d}")

def ym (s ):
    if not s :return None 
    m =re .match (r"(\d{4}-\d{2})",s .strip ())
    return m .group (1 )if m else None 

print ("===== 1. 同花顺补充.csv（只有 url，无内容列）=====")
sup =r"D:\study\date\news\tonghuashunpachong\同花顺补充.csv"
cnt =0 ;url_ex =[];by_month =Counter ()
with open (sup ,encoding ="utf-8-sig")as f :
    r =csv .DictReader (f )
    cols =r .fieldnames 
    for row in r :
        cnt +=1 
        if len (url_ex )<3 :url_ex .append (row .get ("原文链接",""))
        by_month [ym (row .get ("新闻日期",""))]+=1 
print ("List:",cols )
print ("Total number of rows:",cnt )
print ("url example:",url_ex )
print ("Number of items in target month:",sum (v for k ,v in by_month .items ()if k in TARGET_MONTHS ))
print ("Target month distribution:",{k :by_month [k ]for k in sorted (TARGET_MONTHS )if by_month [k ]})

print ("\n===== 2. 合并汇总 A组(有内容新闻_最终去重.jsonl) 目标月份条数 =====")
A =r"D:\study\date\news\111zuixin\合并汇总\有内容新闻_最终去重.jsonl"
a_month =Counter ();a_target =0 ;n =0 
with open (A ,encoding ="utf-8")as f :
    for line in f :
        n +=1 
        r =json .loads (line )
        m =ym (r .get ("date",""))
        if m :a_month [m ]+=1 
        if m in TARGET_MONTHS :a_target +=1 
print ("Total number of items in Group A:",n )
print ("Total number of items in Group A target month:",a_target )
print ("Group A target month by month:",{m :a_month [m ]for m in sorted (TARGET_MONTHS )if a_month [m ]})

print ("\n===== 3. 合并汇总 B组(无正文内容_统计.jsonl) 同花顺来源 + 目标月份 =====")
B =r"D:\study\date\news\111zuixin\合并汇总\无正文内容_统计.jsonl"
b_total =0 ;b_ths =0 ;b_ths_target =0 ;b_by_src =Counter ();b_target_by_month =Counter ()
with open (B ,encoding ="utf-8")as f :
    for line in f :
        r =json .loads (line );b_total +=1 
        src =r .get ("source","")or r .get ("dataset","")
        m =ym (r .get ("date",""))
        if "Flush"in str (src )or "ths"in str (src ).lower ()or "10jqka"in str (src ).lower ():
            b_ths +=1 
            if m in TARGET_MONTHS :
                b_ths_target +=1 ;b_target_by_month [m ]+=1 
        b_by_src [src ]+=1 
print ("Total number of items in Group B:",b_total )
print ("Group B straight flush source number:",b_ths )
print ("Group B Straight Flush + Number of Target Months:",b_ths_target )
print ("Group B Flush + target month Month distribution:",{m :b_target_by_month [m ]for m in sorted (b_target_by_month )})
print ("Group B Source TOP:",b_by_src .most_common (8 ))

print ("\n===== 4. 111zuixin/汇总/新闻汇总_有内容.jsonl 同花顺记录 content 情况 =====")
S =r"D:\study\date\news\111zuixin\汇总\新闻汇总_有内容.jsonl"
if os .path .exists (S ):
    s_total =0 ;s_ths =0 ;s_ths_empty =0 ;s_ths_target =0 
    with open (S ,encoding ="utf-8")as f :
        for line in f :
            r =json .loads (line );s_total +=1 
            ds =str (r .get ("dataset","")+r .get ("source",""))
            if "Flush"in ds or "ths"in ds .lower ()or "10jqka"in ds .lower ():
                s_ths +=1 
                c =r .get ("content","")or ""
                if len (c .strip ())<15 :s_ths_empty +=1 
                if ym (r .get ("date",""))in TARGET_MONTHS :s_ths_target +=1 
    print ("Summary (old) total number of items:",s_total )
    print ("Summary (old) Flush source number:",s_ths )
    print ("Summary (old) Flush source is empty (no content) number of items:",s_ths_empty )
    print ("Summary (old) Flush + number of items in the target month:",s_ths_target )
else :
    print ("The file does not exist")
