# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

import csv, json, re, os
csv.field_size_limit(10_000_000)
BASE=r"D:\study\date\news"
SUP=os.path.join(BASE,"tonghuashunpachong","同花顺补充.csv")
SUP_OUT=os.path.join(BASE,"tonghuashunpachong","同花顺补充_带内容.csv")
B1=os.path.join(BASE,"tonghuashunpachong","crawl_batch1.jsonl")

def norm_url(u):
    u=(u or "").strip(); u=re.sub(r"[#?].*$","",u); u=re.sub(r"/$","",u); return u.lower()

by_url={}
if os.path.exists(B1):
    for line in open(B1,encoding="utf-8"):
        r=json.loads(line); by_url[norm_url(r.get("url",""))]=r.get("content","")

with open(SUP,encoding="utf-8-sig") as f, open(SUP_OUT,"w",encoding="utf-8-sig",newline="") as fo:
    rd=csv.DictReader(f); w=csv.DictWriter(fo, fieldnames=list(rd.fieldnames)+["新闻内容"], quoting=csv.QUOTE_ALL)
    w.writeheader()
    for row in rd:
        c=by_url.get(norm_url(row.get("原文链接","")),"")
        row["新闻内容"]=c.replace("\r"," ").replace("\n"," ")
        w.writerow(row)

n=withc=0
with open(SUP_OUT,encoding="utf-8-sig") as f:
    for row in csv.DictReader(f):
        n+=1
        if len(row.get("新闻内容",""))>=15: withc+=1
print(f"Rebirth CSV: Head Office = {n} Contains text (>=15 words) = {withc}")
