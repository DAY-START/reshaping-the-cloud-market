# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Only continue running Batch 1 (Flush replenishes the target month), and never start Batch 2.
Logic: Reuse the crawling function of crawl_news; first load the successful (B1) and failed (B1_FAILED) URLs,
Preset failed URLs into seen_urls and skip them directly (make sure failed requests are not repeated and wasted), and only crawl untried ones."""
import importlib .util ,json ,os ,time 

PATH =r"C:\Users\ADMIN\WorkBuddy\2026-08-02-01-36-28\crawl_news.py"
spec =importlib .util .spec_from_file_location ("crawl_news",PATH )
m =importlib .util .module_from_spec (spec )
spec .loader .exec_module (m )

# URLs that have failed to be preloaded will be skipped directly (requests will not be repeated)
failed =set ()
if os .path .exists (m .B1_FAILED ):
    with open (m .B1_FAILED ,encoding ="utf-8")as f :
        for line in f :
            try :
                r =json .loads (line )
                failed .add (m .norm_url (r .get ("url","")))
            except Exception :
                pass 
with m .lock :
    m .seen_urls .update (failed )
print (f"Pre-skip historical failure url (determined to be unreachable): {len (failed )}")

t0 =time .time ()
mc =m .batch1 ()
print ("Batch 1 Valid number of items per month:",dict (sorted (mc .items ())))
print (f"\n[Complete] Only batch 1 has ended, batch 2 has not been started. Time consuming{time .time ()-t0 :.1f}s")
