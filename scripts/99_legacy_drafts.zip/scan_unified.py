# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

import json ,os 
from collections import Counter 

p =r"D:\study\date\news\111zuixin\unified\AI_Computing_News_Unified_20210701_20260630.jsonl"
ds_counter =Counter ()
origin_counter =Counter ()
has_source =0 
has_url =0 
content_ok =0 # content is not empty and length>50
valid_date =0 
total =0 
sample_by_ds ={}

with open (p ,encoding ="utf-8")as fh :
    for line in fh :
        line =line .strip ()
        if not line :
            continue 
        try :
            r =json .loads (line )
        except Exception :
            continue 
        total +=1 
        ds =r .get ("_dataset","")or ""
        ds_counter [ds ]+=1 
        origin_counter [r .get ("data_origin","")]+=1 
        if r .get ("source","").strip ():
            has_source +=1 
        if r .get ("url","").strip ():
            has_url +=1 
        c =(r .get ("content")or "").strip ()
        if len (c )>50 :
            content_ok +=1 
        d =(r .get ("date")or "").strip ()
        if d :
            valid_date +=1 
        if ds not in sample_by_ds and total <2_000_000 :
            sample_by_ds [ds ]={k :(str (v )[:40 ])for k ,v in r .items ()}

print ("Total number of records:",total )
print ("With source:",has_source )
print ("With url:",has_url )
print ("content is not empty and >50 words:",content_ok )
print ("With date:",valid_date )
print ("\n=== 按 _dataset 分布 ===")
for k ,v in ds_counter .most_common ():
    print (f"  {k or '(null)'}: {v }")
print ("\n=== 按 data_origin 分布 ===")
for k ,v in origin_counter .most_common ():
    print (f"  {k or '(null)'}: {v }")
