# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""After crawling is completed: sorting and summary + monthly statistics.
Input: computer equipment_merge and remove duplicates_with content.jsonl (successful record of crawling to the text)
Output:
  Computer Equipment_Final Duplication Removal.jsonl (with text, click title + first 150 words of text again to remove duplication)
  Monthly statistics table_computer equipment.csv (month -> number of items)
  Source statistics table_computer equipment.csv (news source -> number of items)"""
import os ,json ,re ,csv 
from collections import Counter 

OUT_DIR =r"D:\study\date\同花顺新闻\合并汇总"
IN =os .path .join (OUT_DIR ,"计算机设备_合并去重_带内容.jsonl")
FINAL =os .path .join (OUT_DIR ,"计算机设备_最终去重.jsonl")
MONTH_CSV =os .path .join (OUT_DIR ,"月度统计表_计算机设备.csv")
SRC_CSV =os .path .join (OUT_DIR ,"来源统计表_计算机设备.csv")

def norm_title (t ):
    return re .sub (r"\s+","",str (t )).lower ()if t else ""

    # Load crawling success record
recs =[]
with open (IN ,"r",encoding ="utf-8")as f :
    for line in f :
        try :
            recs .append (json .loads (line ))
        except Exception :
            continue 
print ("crawled-with-content records:",len (recs ))

# Final duplication removal: (title, first 150 words of text)
seen =set ()
final =[]
dup =0 
for rec in recs :
    title =norm_title (rec .get ("title",""))
    content =rec .get ("content","")or ""
    key =(title ,content [:150 ])
    if key in seen :
        dup +=1 
        continue 
    seen .add (key )
    final .append (rec )
print ("after final dedup:",len (final ),"removed:",dup )

with open (FINAL ,"w",encoding ="utf-8")as f :
    for rec in final :
        f .write (json .dumps (rec ,ensure_ascii =False )+"\n")

        # monthly statistics
mc =Counter ()
for rec in final :
    d =rec .get ("date","")or ""
    if len (d )>=7 :
        mc [d [:7 ]]+=1 
    elif d :
        mc [d [:4 ]]+=1 
months =sorted (mc .keys ())
with open (MONTH_CSV ,"w",encoding ="utf-8-sig",newline ="")as f :
    w =csv .writer (f )
    w .writerow (["月份","新闻条数"])
    for m in months :
        w .writerow ([m ,mc [m ]])
    w .writerow (["合计",sum (mc .values ())])
print ("months:",len (months ),"total:",sum (mc .values ()))

# Source statistics
sc =Counter (rec .get ("source","")or "unknown"for rec in final )
with open (SRC_CSV ,"w",encoding ="utf-8-sig",newline ="")as f :
    w =csv .writer (f )
    w .writerow (["新闻来源","新闻条数"])
    for s ,c in sc .most_common ():
        w .writerow ([s ,c ])
print ("sources:",len (sc ),"top:",sc .most_common (8 ))

# At the same time, a csv with text is generated (for easy browsing, and the text is wrapped)
CSV_VIEW =os .path .join (OUT_DIR ,"计算机设备_最终去重.csv")
with open (CSV_VIEW ,"w",encoding ="utf-8-sig",newline ="")as f :
    w =csv .writer (f )
    w .writerow (["新闻日期","新闻标题","新闻来源","原文链接","新闻正文"])
    for rec in final :
        w .writerow ([
        rec .get ("date",""),rec .get ("title",""),
        rec .get ("source",""),rec .get ("link",""),
        (rec .get ("content","")or "").replace ("\r"," ").replace ("\n"," ")
        ])

print ("OUTPUT:",FINAL )
print ("OUTPUT:",MONTH_CSV )
print ("OUTPUT:",SRC_CSV )
print ("OUTPUT:",CSV_VIEW )
