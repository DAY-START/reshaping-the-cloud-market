# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

import csv ,re ,html ,urllib .request ,urllib .error ,ssl ,json 
from collections import Counter 

csv .field_size_limit (10_000_000 )

# Take the first few items of the supplementary .csv to cover different domain names.
rows =[]
with open (r"D:\study\date\news\tonghuashunpachong\同花顺补充.csv",encoding ="utf-8-sig")as f :
    for i ,row in enumerate (csv .DictReader (f )):
        if i >=40 :break 
        rows .append (row )

seen =set ();samples =[]
for r in rows :
    u =r .get ("原文链接","").strip ()
    dom =re .sub (r"^https?://","",u ).split ("/")[0 ]
    if dom in seen :continue 
    seen .add (dom )
    samples .append ((dom ,u ))
    if len (samples )>=8 :break 

def fetch (u ):
    req =urllib .request .Request (u ,headers ={
    "User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36",
    "Accept":"text/html,application/xhtml+xml,*/*",
    })
    ctx =ssl .create_default_context ()
    ctx .check_hostname =False ;ctx .verify_mode =ssl .CERT_NONE 
    with urllib .request .urlopen (req ,timeout =20 ,context =ctx )as resp :
        return resp .getcode (),resp .read ()

def extract_text (raw ):
# Roughly extract the text: go to script/style and capture <p> and <div> text
    raw =re .sub (rb"<(script|style)[^>]*>.*?</\1>",b"",raw ,flags =re .S |re .I )
    paras =re .findall (rb"<p[^>]*>(.*?)</p>",raw ,flags =re .S |re .I )
    texts =[]
    for p in paras :
        t =re .sub (rb"<[^>]+>",b"",p )
        t =html .unescape (t .decode ("utf-8","ignore")).strip ()
        if len (t )>=10 :texts .append (t )
    joined ="\n".join (texts )
    return joined 

print (f"Number of test domain names: {len (samples )}\n")
for dom ,u in samples :
    try :
        code ,raw =fetch (u )
        txt =extract_text (raw )
        print (f"[OK] {dom }\n code={code } html={len (raw )}B Extract text={len (txt )} words")
        print (f"Text sample: {txt [:120 ].replace (chr (10 ),' ')}")
    except urllib .error .HTTPError as e :
        print (f"[ERR] {dom }  HTTP {e .code }  {u }")
    except Exception as e :
        print (f"[ERR] {dom }  {type (e ).__name__ }: {e }  {u }")
    print ()
