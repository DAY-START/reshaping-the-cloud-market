# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

import csv ,re ,importlib 
import trafilatura 

csv .field_size_limit (10_000_000 )

# Get the URLs of several different domain names in the supplementary .csv
rows =[]
with open (r"D:\study\date\news\tonghuashunpachong\同花顺补充.csv",encoding ="utf-8-sig")as f :
    for i ,row in enumerate (csv .DictReader (f )):
        if i >=60 :break 
        rows .append (row )

seen =set ();samples =[]
for r in rows :
    u =r .get ("原文链接","").strip ()
    dom =re .sub (r"^https?://","",u ).split ("/")[0 ]
    if dom in seen :continue 
    seen .add (dom );samples .append ((dom ,u ))
    if len (samples )>=10 :break 

print (f"Test{len (samples )}domain names\n")
for dom ,u in samples :
    try :
        downloaded =trafilatura .fetch_url (u ,timeout =25 )
        if not downloaded :
            print (f"[Empty] {dom } fetch returns empty");continue 
        txt =trafilatura .extract (downloaded ,include_comments =False ,
        include_tables =False )
        if txt :
            print (f"[OK ] {dom } Text={len (txt )}Word Example: {txt [:90 ].replace (chr (10 ),' ')}")
        else :
            print (f"[None] {dom } The extraction is empty (may require login/anti-crawl/dynamic page)")
    except Exception as e :
        print (f"[ERR] {dom }  {type (e ).__name__ }: {str (e )[:80 ]}")
