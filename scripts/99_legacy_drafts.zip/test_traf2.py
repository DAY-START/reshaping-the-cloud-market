# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

import csv, re
import requests, trafilatura

csv.field_size_limit(10_000_000)
HEADERS={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"}

rows=[]
with open(r"D:\study\date\news\tonghuashunpachong\同花顺补充.csv", encoding="utf-8-sig") as f:
    for i,row in enumerate(csv.DictReader(f)):
        if i>=60: break
        rows.append(row)

seen=set(); samples=[]
for r in rows:
    u=r.get("原文链接","").strip()
    dom=re.sub(r"^https?://", "", u).split("/")[0]
    if dom in seen: continue
    seen.add(dom); samples.append((dom,u))
    if len(samples)>=10: break

print(f"Test{len(samples)}domain names\n")
for dom,u in samples:
    try:
        r=requests.get(u, headers=HEADERS, timeout=25)
        enc=r.apparent_encoding or r.encoding
        raw=r.content
        txt=trafilatura.extract(raw, include_comments=False, include_tables=False)
        if txt:
            print(f"[OK ] {dom} http={r.status_code} Detection code={enc} Text={len(txt)} words")
            print(f"Example: {txt[:80].replace(chr(10),' ')}")
        else:
            print(f"[None] {dom} http={r.status_code} The extraction is empty")
    except Exception as e:
        print(f"[ERR] {dom}  {type(e).__name__}: {str(e)[:80]}")
