# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""S03 training step time-consuming benchmark: estimate the total time of DAPT and fine-tuning, which is used to determine the segmented operation strategy."""
import os 
import time 

import torch 

import v6_s03_damt_transformer as S3 

torch .set_num_threads (max (2 ,(os .cpu_count ()or 4 )-2 ))
torch .manual_seed (0 )

_t ,nn ,F ,DAMT ,focal ,ce =S3 .build_model_classes ()

V =30000 
m =DAMT (V ,use_bias =True ,multi_task =True )
n_par =sum (p .numel ()for p in m .parameters ())
print (f"Parameter amount{n_par /1e6 :.2f}M thread{torch .get_num_threads ()}")

opt =torch .optim .AdamW (m .parameters (),lr =3e-4 )
xb =torch .randint (0 ,V ,(S3 .BATCH ,S3 .L_SEQ ))
tb =torch .randint (0 ,5 ,(S3 .BATCH ,S3 .L_SEQ ))
y =torch .randint (0 ,3 ,(S3 .BATCH ,))

for _ in range (2 ):# preheat
    o =m (xb ,tb )
    loss =sum (F .cross_entropy (o [k ],y [:o [k ].shape [0 ]]%o [k ].shape [1 ])
    for k in o )
    opt .zero_grad ();loss .backward ();opt .step ()

t =time .time ()
NS =10 
for _ in range (NS ):
    o =m (xb ,tb )
    loss =sum (F .cross_entropy (o [k ],y [:o [k ].shape [0 ]]%o [k ].shape [1 ])
    for k in o )
    opt .zero_grad ();loss .backward ();opt .step ()
per =(time .time ()-t )/NS 
print (f"Fine-tuning single step {per *1000 :.0f} ms")

dapt_steps =S3 .DAPT_N //S3 .BATCH *S3 .DAPT_EPOCH 
ft_steps =S3 .FT_N //S3 .BATCH *S3 .FT_EPOCH *5 
print (f"DAPT {dapt_steps } step + fine-tuning {ft_steps } step = {dapt_steps +ft_steps } step")
print (f"Estimated total duration ≈ {(dapt_steps *1.6 +ft_steps )*per /60 :.1f} minutes (DAPT steps are calculated as 1.6 times)")
