# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""v6_cfg_paths.py
================
V6 multi-frequency and DA-Transformer enhanced experimental pipeline - global path and constant configuration.

design principles
--------
1. The *_v1_initial directory is **original data**, which is read-only throughout the process and will never be written or modified.
2. All experimental intermediate products and final results are written to the hierarchical directory under data_v2_experiment/.
3. All scripts are named with the prefix v6_sNN_, and the sequence number is the order of execution."""
from pathlib import Path 

# --------------------------------------------------------------- Root directory
ROOT =Path (r"D:\study\test1")

# ------------------------------------------------------------------ Raw data (read only)
RAW_NEWS_DIR =ROOT /"news_data_v1_initial"
RAW_NEWS_FILE =RAW_NEWS_DIR /"有内容新闻_合并汇总_0802_202107_202606.jsonl"

RAW_STOCK_DIR =ROOT /"stock_data_v1_initial"
RAW_STOCK_FILE =RAW_STOCK_DIR /"all_66stock_final.csv"

RAW_SENT_DIR =ROOT /"investor_sentiment_data_v1_initial"
RAW_SENT_CLEAN =RAW_SENT_DIR /"total_sentiment_clean.csv"
RAW_SENT_TARGET =RAW_SENT_DIR /"sentiment_target_stock.csv"

RAW_IFIND_DIR =ROOT /"ifind_v1_initial"

# ---------------------------------------------------------------- Experimental product (writable)
DATA =ROOT /"data_v2_experiment"
D01_TEXT =DATA /"d01_text_processed"# News cleaning, deduplication, trading day mapping, text
D02_LEX =DATA /"d02_lexicon_tfidf"# Domain dictionary, TF-IDF, article-level scores and weak tags
D03_MODEL =DATA /"d03_model_damt"# DA-MT-FinTransformer model and five-speed ablation
D04_INDEX =DATA /"d04_index_gcs_ugcs"# Daily/Weekly/Month GCS and UGCS
D05_PANEL =DATA /"d05_panel_dataset"# Stock panels, exposures, merged datasets
D06_REG =DATA /"d06_regression_results"# Regression, event studies, local projection results
D07_FIG =DATA /"d07_figures"# Paper graphics (PNG 300dpi)
D08_TAB =DATA /"d08_tables"# Paper table (CSV)
D09_LOG =DATA /"d09_logs"# Run log

for _p in (D01_TEXT ,D02_LEX ,D03_MODEL ,D04_INDEX ,D05_PANEL ,
D06_REG ,D07_FIG ,D08_TAB ,D09_LOG ):
    _p .mkdir (parents =True ,exist_ok =True )

    # ------------------------------------------------------------------ Sample period
SAMPLE_START ="2021-07-01"
SAMPLE_END ="2026-06-30"

# Out-of-time partitioning (for DA-MT-FinTransformer evaluation)
TRAIN_END ="2023-12-31"
VALID_END ="2024-12-31"# The whole year 2024 is the verification set
# 2025-01-01 ~ 2026-06-30 is the out-of-time test set

# ---------------------------------------------------------------- Top issue color (Table 8)
PALETTE ={
"gpu":"#0072B2",# Blue      GPU / positive exposure
"cpu":"#D55E00",# Vermillion CPU / comparison exposure
"spread":"#7B2CBF",# Purple    GPU-CPU spread
"high":"#E76F51",# Coral     High-attention state
"normal":"#2A9D8F",# Teal      Normal / below-threshold state
"raw":"#BDBDBD",# Gray      Raw daily observations
"trend":"#000000",# Black     Moving average / main estimate
}
# Okabe-Ito eight colors (themed stacked area chart)
OKABE_ITO =["#0072B2","#D55E00","#009E73","#CC79A7",
"#E69F00","#56B4E9","#F0E442","#999999"]

FIG_DPI =300 

# --------------------------------------------------------------------- Theme: English Culture
# Figures and text tables should use English topic names (journal formatting requirements).
# The key is the Chinese topic name in the S02 dictionary stage, and the value is the corresponding English label.
TOPIC_EN ={
"订单与出货":"Orders & Shipments",
"产能与资本开支":"Capacity & Capex",
"政策与管制":"Policy & Regulation",
"产品与技术":"Product & Technology",
"供给与价格":"Supply & Pricing",
"业绩与市场":"Earnings & Market",
}


def to_en_topic (s ):
    """Map the Chinese topic names in Series/scalar to English; return the uncollected ones as they are."""
    try :
        return s .map (lambda v :TOPIC_EN .get (v ,v ))
    except AttributeError :
        return TOPIC_EN .get (s ,s )
