# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""pandas3 / numpy2 compatibility smoke test: verify key APIs used in the pipeline."""
import numpy as np 
import pandas as pd 

print ("pandas",pd .__version__ ,"| numpy",np .__version__ )
print ("-"*62 )
fails =[]


def chk (name ,fn ):
    try :
        r =fn ()
        print ("  OK   %-34s %s"%(name ,r ))
    except Exception as e :
        print ("  FAIL %-34s %s: %s"%(name ,type (e ).__name__ ,e ))
        fails .append (name )


df =pd .DataFrame ({
"g":["a","a","b","b","b"],
"b":[1 ,2 ,1 ,2 ,2 ],
"v":[1.0 ,2.0 ,3.0 ,4.0 ,5.0 ],
"w":[1.0 ,1.0 ,2.0 ,1.0 ,1.0 ],
})

chk ("groupby.apply(include_groups=False)",
lambda :float (df .groupby (["g","b"]).apply (
lambda x :np .average (x ["v"],weights =x ["w"]),
include_groups =False ).iloc [0 ]))

chk ("groupby.apply(no kwarg)",
lambda :float (df .groupby ("g").apply (
lambda x :np .average (x ["v"],weights =x ["w"])).iloc [0 ]))

chk ("groupby.transform rolling shift",
lambda :df .groupby ("g")["v"].transform (
lambda s :s .shift (1 ).rolling (2 ,min_periods =1 ).mean ()).notna ().sum ())

chk ("Series.replace(0, nan)",
lambda :pd .Series ([0.0 ,1.0 ]).replace (0 ,np .nan ).isna ().sum ())

chk ("to_datetime + isocalendar",
lambda :pd .to_datetime (pd .Series (["2024-01-05"])).dt .isocalendar ().week .iloc [0 ])

chk ("str slice on read dtype",
lambda :pd .Series (["300750.SZ"]).str [:6 ].iloc [0 ])

chk ("str.extract",
lambda :pd .Series (["SZ300750"]).str .extract (r"(\d{6})")[0 ].iloc [0 ])

chk ("pivot/merge/asof-like sort",
lambda :len (pd .merge (df ,df ,on ="g",how ="left")))

chk ("np.linalg.lstsq rcond=None",
lambda :np .linalg .lstsq (np .random .randn (20 ,3 ),
np .random .randn (20 ),rcond =None )[0 ].shape )

chk ("DataFrame.rolling(min_periods).std",
lambda :float (df ["v"].rolling (3 ,min_periods =2 ).std ().iloc [-1 ]))

chk ("groupby.rank(pct)",
lambda :float (df .groupby ("g")["v"].rank (pct =True ).iloc [0 ]))

chk ("qcut duplicates=drop",
lambda :pd .qcut (pd .Series (np .arange (20.0 )),5 ,
labels =False ,duplicates ="drop").max ())

chk ("clip + fillna chain",
lambda :float (df ["v"].clip (0 ,3 ).fillna (0 ).sum ()))

chk ("concat empty-safe",
lambda :len (pd .concat ([df ,df .iloc [:0 ]],ignore_index =True )))

chk ("to_numpy dtype float",
lambda :df ["v"].to_numpy (dtype =float ).dtype )

chk ("read_csv utf-8-sig + skiprows",
lambda :"n/a (io test skipped)")

chk ("np.nanpercentile",
lambda :float (np .nanpercentile ([1 ,2 ,np .nan ,4 ],90 )))

chk ("np.errstate divide",
lambda :str (np .errstate (divide ="ignore",invalid ="ignore").__class__ .__name__ ))

print ("-"*62 )
print ("FAILS:",",".join (fails )if fails else "NONE — Compatible with all")
