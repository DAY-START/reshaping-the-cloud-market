# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Diagnosis 3: Locate the reason why B1 (DAPT) is inferior to B0 (random initialization).

Three comparisons:
  A randomly initialized (= B0)
  B loads DAPT weight + anchor penalty (= current B1)
  C Load DAPT weights without anchor point penalty
If C ≈ A and B < A, it means that the problem lies in the anchor point;
If C is still < A, it means that the DAPT representation itself is under-trained, and it is necessary to increase the number of DAPT steps or reduce its downstream intervention."""
import time 
import numpy as np 
import torch 
from sklearn .metrics import f1_score 

import v6_s03_damt_transformer as S3 
from v6_cfg_paths import D03_MODEL 

torch .set_num_threads (6 )
ctx =S3 .load_context ()
torch ,DAMT =ctx ["torch"],ctx ["DAMT"]
Y ,tr_idx ,va_idx =ctx ["Y"],ctx ["tr_idx"],ctx ["va_idx"]
alphas =ctx ["alphas"]
ce =ctx ["ce_loss"]

STEPS =300 # Trends can be identified halfway
BATCH =S3 .BATCH 


def run (tag ,use_dapt ,use_anchor ,eta =S3 .ETA_ANCHOR ):
    torch .manual_seed (S3 .SEED )
    m =DAMT (ctx ["V"],use_bias =False ,multi_task =False )
    anchor =None 
    if use_dapt :
        sd =torch .load (D03_MODEL /"dapt_state.pt",weights_only =True )
        m .load_state_dict (sd ,strict =False )
        if use_anchor :
            anchor ={k :v .clone ()for k ,v in m .state_dict ().items ()
            if k in sd and v .shape ==sd [k ].shape 
            and v .dtype .is_floating_point }
    opt =torch .optim .AdamW (m .parameters (),lr =S3 .LR ,weight_decay =0.01 )
    warm =max (10 ,int (STEPS *S3 .WARMUP_FRAC ))
    sch =torch .optim .lr_scheduler .LambdaLR (
    opt ,lambda s :min (1.0 ,(s +1 )/warm )*
    (0.5 *(1 +np .cos (np .pi *min (s /STEPS ,1.0 )))))
    rng =np .random .RandomState (S3 .SEED +7 )
    m .train ();t0 =time .time ();L =[]
    for s in range (STEPS ):
        bi =tr_idx [rng .choice (len (tr_idx ),BATCH ,replace =False )]
        xb ,tb =S3 .batch_of (ctx ,bi )
        o =m (xb ,tb )
        yk =torch .from_numpy (Y ["tone"][bi ].astype (np .int64 ))
        loss =ce (o ["tone"],yk ,alphas ["tone"])
        if anchor is not None :
            pen =sum (((p -anchor [n ])**2 ).mean ()
            for n ,p in m .named_parameters ()if n in anchor )
            loss =loss +eta *pen 
        opt .zero_grad ();loss .backward ()
        torch .nn .utils .clip_grad_norm_ (m .parameters (),1.0 )
        opt .step ();sch .step ()
        L .append (float (loss ))
    m .eval ()
    pr =[]
    with torch .inference_mode ():
        for s in range (0 ,len (va_idx ),256 ):
            bi =va_idx [s :s +256 ]
            xb ,tb =S3 .batch_of (ctx ,bi )
            pr .append (m (xb ,tb )["tone"].argmax (1 ).numpy ())
    pr =np .concatenate (pr )
    yt =Y ["tone"][va_idx ]
    f1 =f1_score (yt ,pr ,average ="macro")
    print (f"{tag :34s} loss {np .mean (L [:20 ]):.3f}->{np .mean (L [-20 :]):.3f} validF1 {f1 :.4f} Predicted distribution {np .bincount (pr ,minlength =3 ).tolist ()} {time .time ()-t0 :.0f}s")
    return f1 


print (f"\nControl experiment ({STEPS } step, only tone header):")
run ("A Random initialization",False ,False )
run ("B DAPT + anchor point (1e-3)",True ,True )
run ("C DAPT no anchor point",True ,False )
