# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Diagnosis 4: How many steps is required for DAPT to produce representations that are useful for downstream purposes.

Idea: MLM head dimension V=24000 is the computing power bottleneck of DAPT. Use weight tying instead.
mlm weights reuse token embedding) can significantly improve sample efficiency; while testing longer training."""
import time 
import numpy as np 
import torch 
import torch .nn as nn 
import torch .nn .functional as F 
from sklearn .metrics import f1_score 

import v6_s03_damt_transformer as S3 
from v6_cfg_paths import D03_MODEL 

torch .set_num_threads (6 )
ctx =S3 .load_context ()
torch ,DAMT =ctx ["torch"],ctx ["DAMT"]
Y ,tr_idx ,va_idx =ctx ["Y"],ctx ["tr_idx"],ctx ["va_idx"]
alphas ,ce =ctx ["alphas"],ctx ["ce_loss"]
V =ctx ["V"]


def dapt_train (steps ,batch =64 ,tie =True ,lr =1e-3 ):
    """Returns the trained DAPT weights and MLM metrics."""
    torch .manual_seed (S3 .SEED )
    m =DAMT (V ,use_bias =True ,multi_task =True )
    if tie :
        m .mlm .weight =m .tok .weight # Weight binding: significantly reducing parameters to be learned
    opt =torch .optim .AdamW (m .parameters (),lr =lr ,weight_decay =0.01 )
    warm =max (10 ,int (steps *0.1 ))
    sch =torch .optim .lr_scheduler .LambdaLR (
    opt ,lambda s :min (1.0 ,(s +1 )/warm )*
    (0.5 *(1 +np .cos (np .pi *min (s /steps ,1.0 )))))
    rng =np .random .RandomState (S3 .SEED +1 )
    pool =np .where (ctx ["is_tr"]|ctx ["is_va"])[0 ]
    m .train ();t0 =time .time ();L =[]
    for s in range (steps ):
        bi =pool [rng .choice (len (pool ),batch ,replace =False )]
        xb ,tb =S3 .batch_of (ctx ,bi )
        prob =torch .rand (xb .shape )
        msk =(prob <0.15 )&(xb !=S3 .PAD )&(xb !=S3 .CLS )
        if not bool (msk .any ()):
            continue 
        tgt =xb [msk ]
        xin =xb .clone ();xin [msk ]=S3 .MASK 
        logit =m (xin ,tb ,mode ="mlm",mlm_pos =msk )
        loss =F .cross_entropy (logit ,tgt )
        opt .zero_grad ();loss .backward ()
        nn .utils .clip_grad_norm_ (m .parameters (),1.0 )
        opt .step ();sch .step ()
        L .append (float (loss ))
    ppl =float (np .exp (np .mean (L [-30 :])))
    print (f"DAPT tie={tie } {steps } step: loss {np .mean (L [:20 ]):.2f}->{np .mean (L [-20 :]):.2f} PPL {ppl :.0f} {time .time ()-t0 :.0f}s")
    return {k :v .clone ()for k ,v in m .state_dict ().items ()},ppl 


def ft_eval (tag ,sd ,steps =300 ):
    torch .manual_seed (S3 .SEED )
    m =DAMT (V ,use_bias =False ,multi_task =False )
    if sd is not None :
        m .load_state_dict (sd ,strict =False )
    opt =torch .optim .AdamW (m .parameters (),lr =S3 .LR ,weight_decay =0.01 )
    warm =max (10 ,int (steps *0.1 ))
    sch =torch .optim .lr_scheduler .LambdaLR (
    opt ,lambda s :min (1.0 ,(s +1 )/warm )*
    (0.5 *(1 +np .cos (np .pi *min (s /steps ,1.0 )))))
    rng =np .random .RandomState (S3 .SEED +7 )
    m .train ()
    for s in range (steps ):
        bi =tr_idx [rng .choice (len (tr_idx ),S3 .BATCH ,replace =False )]
        xb ,tb =S3 .batch_of (ctx ,bi )
        loss =ce (m (xb ,tb )["tone"],
        torch .from_numpy (Y ["tone"][bi ].astype (np .int64 )),
        alphas ["tone"])
        opt .zero_grad ();loss .backward ()
        nn .utils .clip_grad_norm_ (m .parameters (),1.0 )
        opt .step ();sch .step ()
    m .eval ();pr =[]
    with torch .inference_mode ():
        for s in range (0 ,len (va_idx ),256 ):
            bi =va_idx [s :s +256 ]
            xb ,tb =S3 .batch_of (ctx ,bi )
            pr .append (m (xb ,tb )["tone"].argmax (1 ).numpy ())
    pr =np .concatenate (pr )
    f1 =f1_score (Y ["tone"][va_idx ],pr ,average ="macro")
    print (f"  -> {tag :32s} validF1 {f1 :.4f}")
    return f1 


print ("\n[1] 基线：随机初始化")
ft_eval ("random initialization",None )

print ("\n[2] 权重绑定的 DAPT（同等步数）")
sd1 ,_ =dapt_train (500 ,tie =True )
ft_eval ("DAPT-tie 500 steps",sd1 )

print ("\n[3] 权重绑定 + 更长训练")
sd2 ,_ =dapt_train (1200 ,tie =True )
ft_eval ("DAPT-tie 1200 steps",sd2 )
