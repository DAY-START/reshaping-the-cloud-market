# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Training convergence diagnosis: Compare Post-LN / Pre-LN+warmup to locate the reason why the model degrades to a priori prediction."""
import time 
import numpy as np 
import torch 
import torch .nn as nn 
import torch .nn .functional as F 

import v6_s03_damt_transformer as S3 

torch .set_num_threads (6 )
ctx =S3 .load_context ()
Y ,tr_idx =ctx ["Y"],ctx ["tr_idx"]

print ("="*62 )
for k in ["tone","rel","obj","rlt","top"]:
    y =Y [k ][tr_idx ]
    lab =y [y >=0 ]
    c =np .bincount (lab ,minlength =int (Y [k ].max ())+1 )
    frac =c /max (c .sum (),1 )
    ent =-(frac [frac >0 ]*np .log (frac [frac >0 ])).sum ()
    print (f"{k :5s} Annotation {len (lab ):6,} Distribution {c .tolist ()} Proportion {np .round (frac ,3 ).tolist ()} Entropy {ent :.3f}")
print ("="*62 )

# --------- Use small samples to quickly compare the learnability of the two architectures
SUB =6000 
sub =tr_idx [:SUB ]
X ,TG ,rows =ctx ["X"],ctx ["TG"],ctx ["rows"]
r =np .asarray (rows )[sub ]
o =np .argsort (r );inv =np .argsort (o )
xb_all =torch .from_numpy (np .asarray (X [r [o ]]).astype (np .int64 ))[inv ]
tb_all =torch .from_numpy (np .asarray (TG [r [o ]]).astype (np .int64 ))[inv ]
y_all =torch .from_numpy (Y ["tone"][sub ].astype (np .int64 ))
V =ctx ["V"]
print (f"Subsample {SUB } Word list {V }")


class PreBlock (nn .Module ):
    """Pre-LN: The small model is much more stable than Post-LN when trained from scratch, and does not require a long warmup."""

    def __init__ (self ,d ,h ,dff ,p =0.1 ):
        super ().__init__ ()
        self .h ,self .dk =h ,d //h 
        self .q =nn .Linear (d ,d );self .k =nn .Linear (d ,d )
        self .v =nn .Linear (d ,d );self .o =nn .Linear (d ,d )
        self .n1 =nn .LayerNorm (d );self .n2 =nn .LayerNorm (d )
        self .ff =nn .Sequential (nn .Linear (d ,dff ),nn .GELU (),nn .Linear (dff ,d ))
        self .dp =nn .Dropout (p )

    def att (self ,x ,pm ):
        B ,L ,D =x .shape 
        q =self .q (x ).view (B ,L ,self .h ,self .dk ).transpose (1 ,2 )
        k =self .k (x ).view (B ,L ,self .h ,self .dk ).transpose (1 ,2 )
        v =self .v (x ).view (B ,L ,self .h ,self .dk ).transpose (1 ,2 )
        a =q @k .transpose (-1 ,-2 )/(self .dk **0.5 )
        a =a .masked_fill (pm [:,None ,None ,:],-1e4 )
        p =torch .softmax (a ,-1 )
        return self .o ((p @v ).transpose (1 ,2 ).contiguous ().view (B ,L ,D ))

    def forward (self ,x ,pm ):
        x =x +self .dp (self .att (self .n1 (x ),pm ))
        x =x +self .dp (self .ff (self .n2 (x )))
        return x 


class Tiny (nn .Module ):
    def __init__ (self ,V ,pre =True ):
        super ().__init__ ()
        self .pre =pre 
        self .tok =nn .Embedding (V ,S3 .D_MODEL ,padding_idx =0 )
        self .pos =nn .Embedding (S3 .L_SEQ ,S3 .D_MODEL )
        self .seg =nn .Embedding (5 ,S3 .D_MODEL )
        self .dp =nn .Dropout (0.1 )
        if pre :
            self .blocks =nn .ModuleList (
            [PreBlock (S3 .D_MODEL ,S3 .N_HEAD ,S3 .D_FF )for _ in range (S3 .N_LAYER )])
            self .nf =nn .LayerNorm (S3 .D_MODEL )
        else :
            _ ,_ ,_ ,DAMT ,_ ,_ =S3 .build_model_classes ()
            self .inner =DAMT (V ,use_bias =False ,multi_task =False )
        self .head =nn .Linear (S3 .D_MODEL ,3 )

    def forward (self ,x ,tag ):
        if not self .pre :
            return self .inner (x ,tag )["tone"]
        pm =x .eq (0 )
        e =self .tok (x )+self .pos (torch .arange (x .shape [1 ]))[None ]+self .seg (torch .clamp (tag ,0 ,4 ))
        e =self .dp (e )
        for b in self .blocks :
            e =b (e ,pm )
        return self .head (self .nf (e )[:,0 ])


def run (tag ,pre ,lr ,warm ,steps =120 ,bs =128 ):
    torch .manual_seed (7 )
    m =Tiny (V ,pre =pre )
    opt =torch .optim .AdamW (m .parameters (),lr =lr ,weight_decay =0.01 )
    sch =torch .optim .lr_scheduler .LambdaLR (
    opt ,lambda s :min (1.0 ,(s +1 )/max (warm ,1 ))*
    (0.5 *(1 +np .cos (np .pi *min (s /steps ,1.0 ))))if warm else 1.0 )
    rng =np .random .RandomState (0 )
    m .train ();t0 =time .time ();L =[]
    for s in range (steps ):
        bi =rng .choice (SUB ,bs ,replace =False )
        o =m (xb_all [bi ],tb_all [bi ])
        loss =F .cross_entropy (o ,y_all [bi ])
        opt .zero_grad ();loss .backward ()
        nn .utils .clip_grad_norm_ (m .parameters (),1.0 )
        opt .step ();sch .step ()
        L .append (float (loss ))
    m .eval ()
    with torch .inference_mode ():
        pr =[]
        for s in range (0 ,SUB ,512 ):
            pr .append (m (xb_all [s :s +512 ],tb_all [s :s +512 ]).argmax (1 ).numpy ())
    pr =np .concatenate (pr )
    yt =y_all .numpy ()
    from sklearn .metrics import f1_score 
    f1 =f1_score (yt ,pr ,average ="macro")
    uniq =np .bincount (pr ,minlength =3 )
    print (f"{tag :34s} loss {np .mean (L [:10 ]):.3f}->{np .mean (L [-10 :]):.3f} trainF1 {f1 :.3f} predicted distribution {uniq .tolist ()} {time .time ()-t0 :.0f}s")


print ("\n对照实验（训练集自拟合能力，120 步）：")
run ("Post-LN lr3e-4 no warmup (current situation)",False ,3e-4 ,0 )
run ("Pre-LN   lr3e-4  warmup20",True ,3e-4 ,20 )
run ("Pre-LN   lr1e-3  warmup20",True ,1e-3 ,20 )
print ("\n标签自身可学习性上界：训练集若能拟合，说明弱标签含判别信号。")
