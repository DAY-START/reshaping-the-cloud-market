# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Diagnosis 2: Verify whether category weighting + sufficient steps can allow the model to learn the discriminant signal.

The control contains an upper bound for bag-of-words logistic regression - if a linear model can achieve a high F1,
This shows that weak labels are indeed linearly separable from text, and Transformer underfitting is an optimization problem rather than a data problem."""
import time 
import numpy as np 
import torch 
import torch .nn as nn 
import torch .nn .functional as F 
from sklearn .metrics import f1_score 

import v6_s03_damt_transformer as S3 

torch .set_num_threads (6 )
ctx =S3 .load_context ()
Y ,tr_idx ,X ,TG ,rows =ctx ["Y"],ctx ["tr_idx"],ctx ["X"],ctx ["TG"],ctx ["rows"]
V =ctx ["V"]

SUB =8000 
sub =tr_idx [:SUB ]
r =np .asarray (rows )[sub ]
o =np .argsort (r );inv =np .argsort (o )
Xs =np .asarray (X [r [o ]])[inv ]
TGs =np .asarray (TG [r [o ]])[inv ]
ys =Y ["tone"][sub ].astype (np .int64 )

# ---------- Upper bound reference: bag of words + logistic regression
print ("="*64 )
t0 =time .time ()
from scipy .sparse import csr_matrix 
indptr =[0 ];indices =[]
for row in Xs :
    toks =row [row >3 ]
    indices .extend (toks .tolist ())
    indptr .append (len (indices ))
bow =csr_matrix ((np .ones (len (indices ),dtype =np .float32 ),indices ,indptr ),
shape =(SUB ,V ))
from sklearn .linear_model import LogisticRegression 
n_tr =int (SUB *0.8 )
lr =LogisticRegression (max_iter =400 ,class_weight ="balanced",C =1.0 )
lr .fit (bow [:n_tr ],ys [:n_tr ])
p_in =lr .predict (bow [:n_tr ]);p_out =lr .predict (bow [n_tr :])
print (f"Bag of words LR upper bound trainF1 {f1_score (ys [:n_tr ],p_in ,average ='macro'):.3f} holdoutF1 {f1_score (ys [n_tr :],p_out ,average ='macro'):.3f} ({time .time ()-t0 :.0f}s)")
print ("="*64 )

xb_all =torch .from_numpy (Xs .astype (np .int64 ))
tb_all =torch .from_numpy (TGs .astype (np .int64 ))
y_all =torch .from_numpy (ys )

cnt =np .bincount (ys ,minlength =3 ).astype (float )
w =cnt .sum ()/(3 *np .maximum (cnt ,1 ))
wt =torch .tensor (np .clip (w ,0.2 ,5.0 ),dtype =torch .float32 )
print (f"Category weight{np .round (w ,3 ).tolist ()}")


class PreBlock (nn .Module ):
    def __init__ (self ,d ,h ,dff ,p =0.1 ):
        super ().__init__ ()
        self .h ,self .dk =h ,d //h 
        self .q =nn .Linear (d ,d );self .k =nn .Linear (d ,d )
        self .v =nn .Linear (d ,d );self .o =nn .Linear (d ,d )
        self .n1 =nn .LayerNorm (d );self .n2 =nn .LayerNorm (d )
        self .ff =nn .Sequential (nn .Linear (d ,dff ),nn .GELU (),nn .Linear (dff ,d ))
        self .dp =nn .Dropout (p )

    def forward (self ,x ,pm ):
        h =self .n1 (x )
        B ,L ,D =h .shape 
        q =self .q (h ).view (B ,L ,self .h ,self .dk ).transpose (1 ,2 )
        k =self .k (h ).view (B ,L ,self .h ,self .dk ).transpose (1 ,2 )
        v =self .v (h ).view (B ,L ,self .h ,self .dk ).transpose (1 ,2 )
        a =q @k .transpose (-1 ,-2 )/(self .dk **0.5 )
        a =a .masked_fill (pm [:,None ,None ,:],-1e4 )
        att =self .o ((torch .softmax (a ,-1 )@v ).transpose (1 ,2 )
        .contiguous ().view (B ,L ,D ))
        x =x +self .dp (att )
        x =x +self .dp (self .ff (self .n2 (x )))
        return x 


class Tiny (nn .Module ):
    """Pre-LN + mean pooling ([CLS] has weak signal on small models trained from scratch)."""

    def __init__ (self ,V ,nlayer =2 ,pool ="mean"):
        super ().__init__ ()
        self .pool =pool 
        self .tok =nn .Embedding (V ,S3 .D_MODEL ,padding_idx =0 )
        self .pos =nn .Embedding (S3 .L_SEQ ,S3 .D_MODEL )
        self .seg =nn .Embedding (5 ,S3 .D_MODEL )
        self .dp =nn .Dropout (0.1 )
        self .blocks =nn .ModuleList (
        [PreBlock (S3 .D_MODEL ,S3 .N_HEAD ,S3 .D_FF )for _ in range (nlayer )])
        self .nf =nn .LayerNorm (S3 .D_MODEL )
        self .head =nn .Linear (S3 .D_MODEL ,3 )

    def forward (self ,x ,tag ):
        pm =x .eq (0 )
        e =self .tok (x )+self .pos (torch .arange (x .shape [1 ]))[None ]+self .seg (torch .clamp (tag ,0 ,4 ))
        e =self .dp (e )
        for b in self .blocks :
            e =b (e ,pm )
        e =self .nf (e )
        if self .pool =="mean":
            msk =(~pm ).float ().unsqueeze (-1 )
            h =(e *msk ).sum (1 )/msk .sum (1 ).clamp (min =1 )
        else :
            h =e [:,0 ]
        return self .head (h )


def run (tag ,steps ,lr_ ,bs ,weighted ,nlayer =2 ,pool ="mean"):
    torch .manual_seed (7 )
    m =Tiny (V ,nlayer =nlayer ,pool =pool )
    opt =torch .optim .AdamW (m .parameters (),lr =lr_ ,weight_decay =0.01 )
    warm =max (10 ,steps //10 )
    sch =torch .optim .lr_scheduler .LambdaLR (
    opt ,lambda s :min (1.0 ,(s +1 )/warm )*
    (0.5 *(1 +np .cos (np .pi *min (s /steps ,1.0 )))))
    rng =np .random .RandomState (0 )
    m .train ();t0 =time .time ();L =[]
    for s in range (steps ):
        bi =rng .choice (n_tr ,bs ,replace =False )
        out =m (xb_all [bi ],tb_all [bi ])
        loss =F .cross_entropy (out ,y_all [bi ],weight =wt if weighted else None )
        opt .zero_grad ();loss .backward ()
        nn .utils .clip_grad_norm_ (m .parameters (),1.0 )
        opt .step ();sch .step ()
        L .append (float (loss ))
    m .eval ()
    with torch .inference_mode ():
        pr =[]
        for s in range (0 ,SUB ,512 ):
            pr .append (m (xb_all [s :s +512 ],tb_all [s :s +512 ]).argmax (1 ).numpy ())
    pr =np .concatenate (pr )
    f_in =f1_score (ys [:n_tr ],pr [:n_tr ],average ="macro")
    f_out =f1_score (ys [n_tr :],pr [n_tr :],average ="macro")
    print (f"{tag :38s} loss {np .mean (L [:10 ]):.2f}->{np .mean (L [-10 :]):.2f} trainF1 {f_in :.3f} holdF1 {f_out :.3f} predicted distribution {np .bincount (pr ,minlength =3 ).tolist ()} {time .time ()-t0 :.0f}s")


print ("\n对照实验：")
run ("Layer 2 CE unweighted 300 steps lr1e-3",300 ,1e-3 ,128 ,False )
run ("2-layer CE weighted 300 steps lr1e-3",300 ,1e-3 ,128 ,True )
run ("2-layer CE weighted 600 steps lr1e-3",600 ,1e-3 ,128 ,True )
