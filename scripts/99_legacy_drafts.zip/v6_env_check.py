# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

"""Environment self-check: Confirm whether the Python version and the dependency packages required for the experiment are complete."""
import sys 

print ("python",sys .version .split ()[0 ])
print ("exe   ",sys .executable )
print ("-"*60 )

MODS =["numpy","pandas","scipy","sklearn","statsmodels",
"matplotlib","jieba","tqdm","docx","openpyxl","torch"]

missing =[]
for m in MODS :
    try :
        mm =__import__ (m )
        v =getattr (mm ,"__version__","ok")
        print ("  OK   %-14s %s"%(m ,v ))
    except Exception as e :
        print ("  MISS %-14s %s: %s"%(m ,type (e ).__name__ ,e ))
        missing .append (m )

print ("-"*60 )
if missing :
    print ("MISSING:",",".join (missing ))
else :
    print ("ALL DEPENDENCIES READY")

    # torch thread and computing power smoke test
try :
    import torch ,time 
    torch .set_num_threads (4 )
    a =torch .randn (512 ,512 )
    t =time .time ()
    for _ in range (50 ):
        a @a 
    print ("torch matmul512 x50: %.2fs  threads=%d"%(time .time ()-t ,
    torch .get_num_threads ()))
except Exception as e :
    print ("torch bench failed:",e )
