# -*- coding: utf-8 -*-

# ============================================================================
# RESTRICTED USE -- All rights reserved.
# The data, experimental results, and source code in this repository are
# provided for archival / reproducibility reference only. No part of the
# data, experiments, or code may be used, copied, modified, redistributed,
# or incorporated into other works without the author's explicit written
# permission. See LICENSE and NOTICE.md.
# ============================================================================

import os ,json ,csv 

files =[
"D:\\study\\date\\ai_computing_news\\workbuddyai_compute_news_2023_2026.jsonl",
"D:\\study\\date\\ai_computing_news\\yuanbaoai_computing_power_news.jsonl",
"D:\\study\\date\\ai_computing_news\\gptverified_seed_zh.jsonl",
"D:\\study\\date\\ai_computing_news\\crawler_output\\AI_Computing_News_Crawler_20230401_20260630.jsonl",
"D:\\study\\date\\ai_computing_news\\ai_computing_web_collector\\historical_ai_news_output\\AI_Computing_Historical_Web_News_20210701_20260630.jsonl",
"D:\\study\\date\\ai_computing_news\\ai_computing_web_collector\\web_ai_news_output\\AI_Computing_Web_News_20210701_20260630.jsonl",
"D:\\study\\date\\ai_computing_news\\ths_api_download\\AI_Computing_News_THS_Fulltext_Deduplicated.jsonl",
"D:\\study\\date\\ai_computing_news\\ths_api_download\\daily_2026-07-30.jsonl",
"D:\\date新闻数据集\\AI_Computing_News_THS_20210701_20260630.jsonl",
"D:\\study\\test2\\ai_computing_news_202107_202607.jsonl",
"D:\\软件\\python\\项目\\news_work\\final_output\\compute_news_final.jsonl",
"D:\\ai_compute_zh_collector\\verified_seed_zh.jsonl",
"D:\\study\\date\\ai_computing_news\\kimiAI算力新闻数据集_2023-2026.json",
"D:\\study\\date\\ai_computing_news\\doubao算力财经新闻数据集（2026年6-7月，3033条）.jsonl",
"D:\\study\\date\\ai_computing_news\\AI_Computing_News_Raw_after_20210701.jsonl",
]

# Actual copy within 111zuixin (collection folder)
copied_map ={}
for root ,_ ,fs in os .walk (r"D:\study\date\news\111zuixin"):
    for fn in fs :
        copied_map .setdefault (fn ,[]).append (os .path .relpath (os .path .join (root ,fn ),r"D:\study\date\news\111zuixin"))

        # Summarize the number of deduplicated items for each dataset label in JSONL
src_counts ={}
with open (r"D:\study\date\news\111zuixin\汇总\数据集来源统计.csv",encoding ="utf-8-sig")as f :
    for row in csv .DictReader (f ):
        src_counts [row ["来源标签"]]=(row ["读取条数"],row ["符合入选条件"],row ["去重后入选"])

        # Filename -> Description
info ={
files [0 ]:("workbuddy 汇总+摘要","workbuddy","workbuddyai_compute_news_2023_2026.jsonl"),
files [1 ]:("yuanbao 汇总+摘要","yuanbao","yuanbaoai_computing_power_news.jsonl"),
files [2 ]:("gpt_verified 汇总+摘要","gpt_verified","gptverified_seed_zh.jsonl"),
files [3 ]:("crawler 汇总+摘要","crawler","AI_Computing_News_Crawler_20230401_20260630.jsonl"),
files [4 ]:("historical_web 汇总+摘要","historical_web","AI_Computing_Historical_Web_News_20210701_20260630.jsonl"),
files [5 ]:("web_collector 空文件(0字节) 已跳过",None ,"AI_Computing_Web_News_20210701_20260630.jsonl"),
files [6 ]:("ths 汇总+摘要","ths_fulltext_dedup","AI_Computing_News_THS_Fulltext_Deduplicated.jsonl"),
files [7 ]:("ths 汇总+摘要","ths_daily","daily_2026-07-30.jsonl"),
files [8 ]:("ths 汇总+摘要","ths_archive","AI_Computing_News_THS_20210701_20260630.jsonl"),
files [9 ]:("test2 实验副本 已跳过",None ,"ai_computing_news_202107_202607.jsonl"),
files [10 ]:("catalog记录但文件不存在(已删除/路径变更)",None ,"compute_news_final.jsonl"),
files [11 ]:("与gpt_verified同内容 重复 已跳过",None ,"verified_seed_zh.jsonl"),
files [12 ]:("kimi 汇总+摘要","kimi","kimiAI算力新闻数据集_2023-2026.json"),
files [13 ]:("doubao 汇总+摘要","doubao","doubao算力财经新闻数据集（2026年6-7月，3033条）.jsonl"),
files [14 ]:("datelab_raw 已复制(归入datelab_raw/)，摘要改用unified(已包含其全部数据)","datelab_unified(等价)","AI_Computing_News_Raw_after_20210701.jsonl"),
}

print (f"{'文件名':52s} {'exist':5s} {'Copied':6s} {'Enter abstract':7s} Remarks")
print ("-"*150 )
for p in files :
    exists =os .path .isfile (p )
    fname =os .path .basename (p )
    copied =fname in copied_map 
    note ,label ,_ =info [p ]
    in_summary ="-"
    if label and label in src_counts :
        in_summary ="yes("+src_counts [label ][2 ]+")"
    elif label =="datelab_unified(等价)":
        in_summary ="is (unified,"+src_counts .get ("datelab_unified",("","",""))[2 ]+")"
    elif "jump over"in note or "does not exist"in note :
        in_summary ="no"
    print (f"{fname [:50 ]:52s} {('Y'if exists else 'N'):5s} {('Y'if copied else 'N'):6s} {in_summary :7s}  {note }")
